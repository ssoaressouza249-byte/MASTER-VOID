package com.raylan.mastervoid

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.mastervoid.model.MasterVoidCatalog
import com.raylan.mastervoid.security.SecurityGuard
import com.raylan.mastervoid.ui.theme.MasterVoidThemes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MasterVoidRobolectricTest {

  @Test
  fun `app name matches Master Void`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Master Void", appName)
  }

  @Test
  fun `theme palette provides 10 colors`() {
    assertEquals(10, MasterVoidThemes.size)
  }

  @Test
  fun `catalog contains master scripts with preview commands`() {
    assertTrue(MasterVoidCatalog.masterScripts.isNotEmpty())
    assertTrue(MasterVoidCatalog.allFeatures.size >= 40)
  }
}
