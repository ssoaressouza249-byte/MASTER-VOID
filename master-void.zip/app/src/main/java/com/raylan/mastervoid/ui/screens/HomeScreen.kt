package com.raylan.mastervoid.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MotionPhotosAuto
import androidx.compose.material.icons.filled.MotionPhotosOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.mastervoid.R
import com.raylan.mastervoid.model.MasterVoidCatalog
import com.raylan.mastervoid.model.MasterVoidState
import com.raylan.mastervoid.model.PowerProfile
import com.raylan.mastervoid.shizuku.ShizukuStatus
import com.raylan.mastervoid.telemetry.HardwareTelemetry
import com.raylan.mastervoid.telemetry.TempBadge
import com.raylan.mastervoid.ui.components.MasterVoidFooter
import com.raylan.mastervoid.ui.components.VoidCardContainer
import com.raylan.mastervoid.ui.components.VoidFeatureToggleRow
import com.raylan.mastervoid.ui.components.VoidSearchBar
import com.raylan.mastervoid.ui.components.VoidSectionHeader
import com.raylan.mastervoid.ui.theme.VoidAmber
import com.raylan.mastervoid.ui.theme.VoidBorder
import com.raylan.mastervoid.ui.theme.VoidCard
import com.raylan.mastervoid.ui.theme.VoidCardElevated
import com.raylan.mastervoid.ui.theme.VoidGreen
import com.raylan.mastervoid.ui.theme.VoidRed
import com.raylan.mastervoid.ui.theme.VoidTextMuted
import com.raylan.mastervoid.ui.theme.VoidTextPrimary
import com.raylan.mastervoid.ui.theme.VoidTextSecondary

@Composable
fun HomeScreen(
    state: MasterVoidState,
    telemetry: HardwareTelemetry,
    shizukuStatus: ShizukuStatus,
    onToggleBannerAnimation: () -> Unit,
    onRequestShizuku: () -> Unit,
    onSelectProfile: (PowerProfile) -> Unit,
    onToggleFeature: (String) -> Unit,
    onToggleFavorite: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val searchMatches = remember(searchQuery) {
        if (searchQuery.isBlank()) emptyList()
        else MasterVoidCatalog.allFeatures.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                it.subtitle.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    val favoriteFeatures = remember(state.favoriteFeatureIds) {
        MasterVoidCatalog.allFeatures.filter { it.id in state.favoriteFeatureIds }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(6.dp))
            RobotSunHeroBanner(
                animateBanner = state.animateBanner,
                currentMode = state.currentProfile.label,
                onToggleAnimation = onToggleBannerAnimation
            )
        }

        item {
            VoidSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Buscar: lag, calor, mira..."
            )
        }

        if (searchQuery.isNotBlank()) {
            item {
                VoidSectionHeader(
                    title = "Resultados da busca",
                    subtitle = "${searchMatches.size} funções encontradas"
                )
            }
            if (searchMatches.isEmpty()) {
                item {
                    VoidCardContainer {
                        Text(
                            text = "Nenhuma função encontrada para \"$searchQuery\".",
                            style = MaterialTheme.typography.bodyMedium,
                            color = VoidTextSecondary
                        )
                    }
                }
            } else {
                items(searchMatches, key = { "search_${it.id}" }) { meta ->
                    VoidFeatureToggleRow(
                        featureId = meta.id,
                        title = meta.title,
                        subtitle = "${meta.category} • ${meta.subtitle}",
                        checked = meta.id in state.enabledFeatureIds,
                        onCheckedChange = { onToggleFeature(meta.id) },
                        isFavorite = meta.id in state.favoriteFeatureIds,
                        onFavoriteToggle = { onToggleFavorite(meta.id) },
                        hapticEnabled = state.hapticOnTap
                    )
                }
            }
        } else {
            item {
                HardwareTelemetryCard(
                    telemetry = telemetry,
                    shizukuStatus = shizukuStatus,
                    currentMode = state.currentProfile.label,
                    onRequestShizuku = onRequestShizuku
                )
            }

            item {
                VoidSectionHeader(
                    title = "Perfis Prontos",
                    subtitle = "Ajuste imediato de FPS, Bateria e Térmica"
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PowerProfile.entries.forEach { profile ->
                        ProfileCard(
                            profile = profile,
                            selected = state.currentProfile == profile,
                            onClick = { onSelectProfile(profile) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                VoidSectionHeader(
                    title = "Favoritos",
                    subtitle = "Fixe funções com a estrela nas abas Jogo e Sistema",
                    badge = "${favoriteFeatures.size}"
                )
            }

            if (favoriteFeatures.isEmpty()) {
                item {
                    VoidCardContainer {
                        Text(
                            text = "Toque na estrela de qualquer função para fixar aqui.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = VoidTextSecondary
                        )
                    }
                }
            } else {
                items(favoriteFeatures, key = { "fav_${it.id}" }) { meta ->
                    VoidFeatureToggleRow(
                        featureId = meta.id,
                        title = meta.title,
                        subtitle = "${meta.category} • ${meta.subtitle}",
                        checked = meta.id in state.enabledFeatureIds,
                        onCheckedChange = { onToggleFeature(meta.id) },
                        isFavorite = true,
                        onFavoriteToggle = { onToggleFavorite(meta.id) },
                        hapticEnabled = state.hapticOnTap
                    )
                }
            }
        }

        item {
            MasterVoidFooter()
        }
    }
}

@Composable
private fun RobotSunHeroBanner(
    animateBanner: Boolean,
    currentMode: String,
    onToggleAnimation: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hero_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.045f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hero_scale"
    )
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(176.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, primary.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_robot_sun_hero),
            contentDescription = "Robô futurista segurando um sol brilhante",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    if (animateBanner) {
                        scaleX = scale
                        scaleY = scale
                    }
                }
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x330B0B10),
                            Color(0xCC0B0B10)
                        )
                    )
                )
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopEnd)
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xB30B0B10))
                    .border(1.dp, secondary.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "MODO $currentMode".uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = secondary,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(
                onClick = onToggleAnimation,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xAA14141E))
                    .testTag("toggle_banner_anim")
            ) {
                Icon(
                    imageVector = if (animateBanner) Icons.Filled.MotionPhotosAuto else Icons.Filled.MotionPhotosOff,
                    contentDescription = "Ligar ou desligar animação do banner",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(14.dp)
        ) {
            Text(
                text = "Master Void",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Suíte gamer completa • Hardware, Hz, Toque, Áudio & Shizuku",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFD1D5DB)
            )
        }
    }
}

@Composable
private fun HardwareTelemetryCard(
    telemetry: HardwareTelemetry,
    shizukuStatus: ShizukuStatus,
    currentMode: String,
    onRequestShizuku: () -> Unit
) {
    val tempColor = when (telemetry.tempBadge) {
        TempBadge.COLD -> VoidGreen
        TempBadge.WARM -> VoidAmber
        TempBadge.HOT -> VoidRed
    }
    val shizukuColor = when (shizukuStatus) {
        ShizukuStatus.READY -> VoidGreen
        ShizukuStatus.PERMISSION_REQUIRED -> VoidAmber
        ShizukuStatus.DISCONNECTED, ShizukuStatus.NOT_INSTALLED -> VoidRed
    }

    VoidCardContainer(highlighted = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Hardware & Telemetria ao Vivo",
                    style = MaterialTheme.typography.titleMedium,
                    color = VoidTextPrimary
                )
                Text(
                    text = telemetry.deviceModel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Surface(
                onClick = onRequestShizuku,
                shape = RoundedCornerShape(10.dp),
                color = shizukuColor.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, shizukuColor.copy(alpha = 0.55f)),
                modifier = Modifier.testTag("shizuku_status_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Terminal,
                        contentDescription = "Status Shizuku",
                        tint = shizukuColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Shizuku: ${shizukuStatus.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = shizukuColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryMiniBox(
                label = "GPU",
                value = telemetry.gpuName,
                modifier = Modifier.weight(1f)
            )
            TelemetryMiniBox(
                label = "Tela Atual",
                value = "${telemetry.currentRefreshHz} Hz",
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryMiniBox(
                label = "Chip / SoC",
                value = telemetry.chipSoc,
                modifier = Modifier.weight(1f)
            )
            TelemetryMiniBox(
                label = "Android / API",
                value = telemetry.androidVersionLabel,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TelemetryMiniBox(
                label = "RAM Livre / Total",
                value = "${telemetry.ramFreeMb} / ${telemetry.ramTotalMb} MB",
                modifier = Modifier.weight(1f)
            )
            Surface(
                modifier = Modifier.weight(1f),
                color = VoidCardElevated,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, VoidBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Bateria & Modo",
                        style = MaterialTheme.typography.labelSmall,
                        color = VoidTextMuted
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${telemetry.batteryTempC}°C",
                            style = MaterialTheme.typography.labelMedium,
                            color = VoidTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(tempColor.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = telemetry.tempBadge.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = tempColor
                            )
                        }
                    }
                    Text(
                        text = "Modo: $currentMode • ${telemetry.batteryPercent}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryMiniBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = VoidCardElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, VoidBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = VoidTextMuted
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = VoidTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ProfileCard(
    profile: PowerProfile,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val icon = when (profile) {
        PowerProfile.BATTERY -> Icons.Filled.BatteryChargingFull
        PowerProfile.BALANCED -> Icons.Filled.Speed
        PowerProfile.MAXIMUM -> Icons.Filled.Bolt
    }

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("profile_${profile.name.lowercase()}"),
        color = if (selected) primary.copy(alpha = 0.14f) else VoidCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) primary else VoidBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = profile.label,
                    tint = if (selected) secondary else VoidTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = profile.label,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (selected) Color.White else VoidTextPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            ProfileStatBar("FPS", profile.fpsBar, secondary)
            ProfileStatBar("Bat", profile.batteryBar, VoidGreen)
            ProfileStatBar("Frio", profile.coolBar, primary)
        }
    }
}

@Composable
private fun ProfileStatBar(label: String, progress: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = VoidTextMuted)
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = VoidTextSecondary)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = color,
            trackColor = VoidBorder
        )
    }
}
