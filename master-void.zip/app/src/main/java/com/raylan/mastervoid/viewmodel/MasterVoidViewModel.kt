package com.raylan.mastervoid.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.drawable.Drawable
import android.provider.Settings
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.mastervoid.audio.AudioOptimizerManager
import com.raylan.mastervoid.audio.AudioPreset
import com.raylan.mastervoid.audio.AudioSettingsState
import com.raylan.mastervoid.data.MasterVoidPreferences
import com.raylan.mastervoid.model.ActivityLogEntry
import com.raylan.mastervoid.model.AddedGameItem
import com.raylan.mastervoid.model.AppLanguage
import com.raylan.mastervoid.model.DpiTestState
import com.raylan.mastervoid.model.HzAppRule
import com.raylan.mastervoid.model.MasterScriptItem
import com.raylan.mastervoid.model.MasterVoidCatalog
import com.raylan.mastervoid.model.MasterVoidState
import com.raylan.mastervoid.model.PowerProfile
import com.raylan.mastervoid.security.SecurityCheckResult
import com.raylan.mastervoid.security.SecurityGuard
import com.raylan.mastervoid.service.FloatingHudService
import com.raylan.mastervoid.shizuku.ShizukuEngine
import com.raylan.mastervoid.shizuku.ShizukuStatus
import com.raylan.mastervoid.telemetry.HardwareTelemetry
import com.raylan.mastervoid.telemetry.HardwareTelemetryManager
import com.raylan.mastervoid.telemetry.InstalledAppItem
import com.raylan.mastervoid.ui.theme.MasterVoidThemes
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MasterVoidViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val preferences = MasterVoidPreferences(context)
    private val telemetryManager = HardwareTelemetryManager(context)
    val shizukuEngine = ShizukuEngine(context)
    private val audioManager = AudioOptimizerManager(context)

    private val initialSnapshot = telemetryManager.collectSnapshot()

    private val _state = MutableStateFlow(
        MasterVoidState(
            originalDpi = initialSnapshot.densityDpi,
            currentDpi = initialSnapshot.densityDpi
        )
    )
    val state: StateFlow<MasterVoidState> = _state.asStateFlow()

    private val _telemetry = MutableStateFlow(initialSnapshot)
    val telemetry: StateFlow<HardwareTelemetry> = _telemetry.asStateFlow()

    private val _securityStatus = MutableStateFlow(SecurityGuard.verifyIntegrity(context))
    val securityStatus: StateFlow<SecurityCheckResult> = _securityStatus.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppItem>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppItem>> = _installedApps.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    val shizukuStatus: StateFlow<ShizukuStatus> = shizukuEngine.status

    private var dpiCountdownJob: Job? = null
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    init {
        shizukuEngine.initialize()
        loadInitialData()
        startTelemetryLoop()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            val saved = preferences.observeState(initialSnapshot.densityDpi).first()
            _state.value = saved
            audioManager.applySettings(saved.masterEnabled, saved.audioState)
            val apps = telemetryManager.getInstalledApps(includeSystem = false)
            _installedApps.value = apps
        }
    }

    private fun startTelemetryLoop() {
        viewModelScope.launch {
            while (isActive) {
                _telemetry.value = telemetryManager.collectSnapshot()
                shizukuEngine.refreshStatus()
                delay(2500L)
            }
        }
    }

    fun reverifySecurity() {
        _securityStatus.value = SecurityGuard.verifyIntegrity(context)
    }

    fun triggerSecurityUninstall() {
        SecurityGuard.triggerUninstallIntent(context)
    }

    fun clearStatusMessage() {
        _statusBannerMessage.value = null
    }

    fun loadAppIcon(packageName: String): Drawable? = telemetryManager.loadAppIcon(packageName)

    fun refreshInstalledApps(includeSystem: Boolean = false) {
        viewModelScope.launch {
            _installedApps.value = telemetryManager.getInstalledApps(includeSystem)
        }
    }

    fun toggleMasterEnabled() {
        val current = _state.value
        val nextEnabled = !current.masterEnabled
        updateAndPersist { it.copy(masterEnabled = nextEnabled) }
        viewModelScope.launch {
            if (!nextEnabled) {
                shizukuEngine.undoAll()
                audioManager.resetAudioEffects()
                FloatingHudService.updateOverlay(
                    context = context,
                    showHud = false,
                    showCrosshair = false,
                    crosshairStyle = current.crosshairStyle,
                    accentColorInt = currentAccentArgb()
                )
                appendLog("Master Void Desativado", "Todas as otimizações revertidas com 1 toque", false, true)
                _statusBannerMessage.value = "Master Void pausado e alterações revertidas."
            } else {
                audioManager.applySettings(true, current.audioState)
                syncOverlayService()
                reapplyActiveShizukuFeatures()
                appendLog("Master Void Ativado", "Perfil ${current.currentProfile.label} em execução", shizukuStatus.value == ShizukuStatus.READY, true)
                _statusBannerMessage.value = "Master Void ativado (${activeFeatureCount()} funções)."
            }
        }
    }

    fun activeFeatureCount(): Int {
        val s = _state.value
        if (!s.masterEnabled) return 0
        var count = s.enabledFeatureIds.size
        if (s.weakChipHelpActive) count++
        if (s.lockedFpsEnabled) count++
        if (s.uiVulkanEnabled) count++
        if (s.floatingCrosshairEnabled) count++
        if (s.floatingHudEnabled) count++
        if (s.audioState.preset != AudioPreset.OFF) count++
        if (s.forbiddenBackgroundApps.isNotEmpty()) count++
        return count
    }

    fun selectProfile(profile: PowerProfile) {
        updateAndPersist {
            val nextEnabled = when (profile) {
                PowerProfile.BATTERY -> setOf("auto_detect", "fps_adaptive", "hz_adaptive", "sys_fast_doze", "sys_eco_location")
                PowerProfile.BALANCED -> setOf("auto_detect", "smart_detect", "fps_adaptive", "hz_adaptive", "light_anim", "ia_master")
                PowerProfile.MAXIMUM -> setOf("auto_detect", "smart_detect", "perf_mode", "hz_max", "no_blur", "zero_anim", "touch_sensitive", "ia_master")
            }
            it.copy(currentProfile = profile, enabledFeatureIds = nextEnabled)
        }
        viewModelScope.launch {
            val cmd = when (profile) {
                PowerProfile.BATTERY -> "cmd power set-fixed-performance-mode-enabled false && settings put global window_animation_scale 1.0"
                PowerProfile.BALANCED -> "cmd power set-fixed-performance-mode-enabled false && settings put global window_animation_scale 0.5"
                PowerProfile.MAXIMUM -> "cmd power set-fixed-performance-mode-enabled true && settings put global window_animation_scale 0.5"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("Perfil ${profile.label}", res.output, res.usedShizuku, res.success)
            _statusBannerMessage.value = "Perfil ${profile.label} aplicado."
        }
    }

    fun toggleFavorite(featureId: String) {
        updateAndPersist { s ->
            val updated = if (featureId in s.favoriteFeatureIds) {
                s.favoriteFeatureIds - featureId
            } else {
                s.favoriteFeatureIds + featureId
            }
            s.copy(favoriteFeatureIds = updated)
        }
    }

    fun toggleFeature(featureId: String) {
        val meta = MasterVoidCatalog.allFeatures.find { it.id == featureId }
        val wasEnabled = featureId in _state.value.enabledFeatureIds
        val nowEnabled = !wasEnabled

        updateAndPersist { s ->
            val nextSet = if (nowEnabled) s.enabledFeatureIds + featureId else s.enabledFeatureIds - featureId
            s.copy(enabledFeatureIds = nextSet)
        }

        if (meta != null) {
            viewModelScope.launch {
                val cmd = if (nowEnabled) meta.applyCmd else meta.undoCmd
                if (cmd.isNotBlank()) {
                    val res = if (nowEnabled) {
                        shizukuEngine.executeWithUndo(meta.id, meta.title, meta.applyCmd, meta.undoCmd)
                    } else {
                        shizukuEngine.undoAction(meta.id) ?: shizukuEngine.runCommand(cmd)
                    }
                    appendLog(
                        "${meta.title} (${if (nowEnabled) "Ligado" else "Desligado"})",
                        res.output,
                        res.usedShizuku,
                        res.success
                    )
                } else {
                    appendLog(
                        meta.title,
                        if (nowEnabled) "Ativado no motor Master Void" else "Desativado",
                        false,
                        true
                    )
                }
            }
        }
    }

    fun addGame(app: InstalledAppItem) {
        updateAndPersist { s ->
            if (s.addedGames.any { it.packageName == app.packageName }) s
            else s.copy(addedGames = s.addedGames + AddedGameItem(app.packageName, app.label, playTimeMinutes = 0))
        }
        appendLog("Jogo adicionado", "${app.label} (${app.packageName})", false, true)
    }

    fun removeGame(packageName: String) {
        updateAndPersist { s ->
            s.copy(addedGames = s.addedGames.filterNot { it.packageName == packageName })
        }
    }

    fun launchGame(game: AddedGameItem) {
        updateAndPersist { s ->
            s.copy(addedGames = s.addedGames.map {
                if (it.packageName == game.packageName) it.copy(playTimeMinutes = it.playTimeMinutes + 15) else it
            })
        }
        viewModelScope.launch {
            if (_state.value.masterEnabled) {
                shizukuEngine.runCommand("cmd game mode performance ${game.packageName}")
            }
            val launchIntent = context.packageManager.getLaunchIntentForPackage(game.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(launchIntent) }
                appendLog("Play direto", "Iniciando ${game.name} otimizado", shizukuStatus.value == ShizukuStatus.READY, true)
            } else {
                _statusBannerMessage.value = "Não foi possível abrir ${game.name}"
            }
        }
    }

    fun setGameResolutionScale(scale: String) {
        updateAndPersist { it.copy(gameResolutionScale = scale) }
        val numericScale = when (scale) {
            "100%" -> "1.0"
            "90%" -> "0.9"
            "80%" -> "0.8"
            "70%" -> "0.7"
            "60%" -> "0.6"
            else -> null
        }
        viewModelScope.launch {
            val targetPkg = _state.value.addedGames.firstOrNull()?.packageName
            val cmd = if (numericScale != null && targetPkg != null) {
                "cmd game set --downscale $numericScale $targetPkg"
            } else {
                "cmd game set --downscale disable ${targetPkg ?: "com.example"}"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("Resolução do jogo: $scale", res.output, res.usedShizuku, res.success)
        }
    }

    fun setGameTargetFps(fps: String) {
        updateAndPersist { it.copy(gameTargetFps = fps) }
        viewModelScope.launch {
            val targetPkg = _state.value.addedGames.firstOrNull()?.packageName ?: "global"
            val cmd = if (fps == "Auto") {
                "cmd game set --fps 0 $targetPkg"
            } else {
                "cmd game set --fps $fps $targetPkg"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("FPS do jogo: $fps", res.output, res.usedShizuku, res.success)
        }
    }

    fun toggleStretchedScreen() {
        val next = !_state.value.stretchedGameScreen
        updateAndPersist { it.copy(stretchedGameScreen = next) }
        appendLog("Tela do Jogo (FOV Esticado)", if (next) "Ativado" else "Padrão", false, true)
    }

    fun setGraphicPath(path: String) {
        updateAndPersist { it.copy(graphicPath = path) }
        viewModelScope.launch {
            val cmd = when (path) {
                "ANGLE" -> "settings put global angle_gl_driver_all_angle 1"
                "Driver" -> "settings put global updatable_driver_all_apps 1"
                "Modo Jogo" -> "cmd game mode performance"
                else -> "settings put global angle_gl_driver_all_angle 0"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("Caminho gráfico: $path", res.output, res.usedShizuku, res.success)
        }
    }

    fun toggleWeakChipHelp() {
        val next = !_state.value.weakChipHelpActive
        updateAndPersist { it.copy(weakChipHelpActive = next) }
        viewModelScope.launch {
            val cmd = if (next) {
                "settings put global window_animation_scale 0.5 && settings put global disable_window_blurs 1 && pm trim-caches 512M"
            } else {
                "settings put global window_animation_scale 1.0 && settings put global disable_window_blurs 0"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("Ajuda pra Chip Fraco", if (next) "Ativada: 70% escala + zero blur" else "Desativada", res.usedShizuku, res.success)
        }
    }

    fun setHzAppRule(rule: HzAppRule) {
        updateAndPersist { it.copy(hzPerAppRule = rule) }
    }

    fun addHzApp(packageName: String) {
        updateAndPersist { it.copy(hzAppPackages = it.hzAppPackages + packageName) }
    }

    fun clearHzApps() {
        updateAndPersist { it.copy(hzAppPackages = emptySet()) }
    }

    fun toggleLockedFps() {
        val next = !_state.value.lockedFpsEnabled
        updateAndPersist { it.copy(lockedFpsEnabled = next) }
        viewModelScope.launch {
            val hzNum = _state.value.lockedFpsTarget.filter { it.isDigit() }.ifBlank { "60" }
            val cmd = if (next) {
                "settings put system min_refresh_rate $hzNum.0 && settings put system peak_refresh_rate $hzNum.0"
            } else {
                "settings delete system min_refresh_rate && settings delete system peak_refresh_rate"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("FPS Cravado", if (next) "${_state.value.lockedFpsTarget} (${_state.value.lockedFpsMode})" else "Desligado", res.usedShizuku, res.success)
        }
    }

    fun setLockedFpsTarget(target: String) {
        updateAndPersist { it.copy(lockedFpsTarget = target) }
    }

    fun setLockedFpsMode(mode: String) {
        updateAndPersist { it.copy(lockedFpsMode = mode) }
    }

    fun toggleUiVulkan() {
        val next = !_state.value.uiVulkanEnabled
        updateAndPersist { it.copy(uiVulkanEnabled = next) }
        viewModelScope.launch {
            val cmd = if (next) "setprop debug.hwui.renderer skiavk" else "setprop debug.hwui.renderer skiagl"
            val res = shizukuEngine.runCommand(cmd)
            appendLog("UI por Vulkan", res.output, res.usedShizuku, res.success)
        }
    }

    fun setVividColors(level: String) {
        updateAndPersist { it.copy(vividColorsLevel = level) }
        viewModelScope.launch {
            val value = if (level == "Desligado") "1.0" else level
            val res = shizukuEngine.runCommand("service call SurfaceFlinger 1022 f $value")
            appendLog("Cores Vivas ($level)", res.output, res.usedShizuku, res.success)
        }
    }

    fun setGameColorProfile(profile: String) {
        updateAndPersist { it.copy(gameColorProfile = profile) }
    }

    fun setDarkVision(level: String) {
        updateAndPersist { it.copy(darkVisionLevel = level) }
    }

    fun setStrongContrast(level: String) {
        updateAndPersist { it.copy(strongContrastLevel = level) }
    }

    fun startDpiTest(targetDpi: Int) {
        val orig = _state.value.originalDpi
        dpiCountdownJob?.cancel()
        _state.update {
            it.copy(
                currentDpi = targetDpi,
                dpiTestState = DpiTestState(
                    isTesting = true,
                    targetDpi = targetDpi,
                    originalDpi = orig,
                    secondsRemaining = 15
                )
            )
        }
        viewModelScope.launch {
            val res = shizukuEngine.runCommand("wm density $targetDpi")
            appendLog("Teste DPI ($targetDpi)", res.output, res.usedShizuku, res.success)
        }
        dpiCountdownJob = viewModelScope.launch {
            for (sec in 14 downTo 0) {
                delay(1000L)
                if (!_state.value.dpiTestState.isTesting) return@launch
                if (sec == 0) {
                    revertDpiToOriginal()
                } else {
                    _state.update { s ->
                        s.copy(dpiTestState = s.dpiTestState.copy(secondsRemaining = sec))
                    }
                }
            }
        }
    }

    fun keepTestedDpi() {
        dpiCountdownJob?.cancel()
        val tested = _state.value.dpiTestState.targetDpi
        updateAndPersist {
            it.copy(
                currentDpi = tested,
                dpiTestState = DpiTestState(isTesting = false, targetDpi = tested, originalDpi = it.originalDpi)
            )
        }
        appendLog("DPI Mantido", "Novo DPI confirmado em $tested", shizukuStatus.value == ShizukuStatus.READY, true)
    }

    fun revertDpiToOriginal() {
        dpiCountdownJob?.cancel()
        val orig = _state.value.originalDpi
        updateAndPersist {
            it.copy(
                currentDpi = orig,
                dpiTestState = DpiTestState(isTesting = false, targetDpi = orig, originalDpi = orig)
            )
        }
        viewModelScope.launch {
            val res = shizukuEngine.runCommand("wm density reset")
            appendLog("DPI Original Restaurado", res.output, res.usedShizuku, res.success)
        }
    }

    fun toggleProtectResolution() {
        updateAndPersist { it.copy(protectResolution = !it.protectResolution) }
    }

    fun setLongPressMs(value: String) {
        updateAndPersist { it.copy(longPressMs = value) }
        val ms = value.filter { it.isDigit() }.ifBlank { "400" }
        viewModelScope.launch {
            val res = shizukuEngine.runCommand("settings put secure long_press_timeout $ms")
            appendLog("Toque Longo: $value", res.output, res.usedShizuku, res.success)
        }
    }

    fun setDoubleTapMs(value: String) {
        updateAndPersist { it.copy(doubleTapMs = value) }
    }

    fun setPointerSpeed(value: String) {
        updateAndPersist { it.copy(pointerSpeed = value) }
        viewModelScope.launch {
            val res = shizukuEngine.runCommand("settings put system pointer_speed $value")
            appendLog("Velocidade do ponteiro: $value", res.output, res.usedShizuku, res.success)
        }
    }

    fun setTouchWhenActive(mode: String) {
        updateAndPersist { it.copy(touchWhenActive = mode) }
    }

    fun toggleFloatingCrosshair() {
        val next = !_state.value.floatingCrosshairEnabled
        if (next && !Settings.canDrawOverlays(context)) {
            _statusBannerMessage.value = "Conceda permissão de sobreposição (SYSTEM_ALERT_WINDOW) para exibir a Mira Flutuante."
            return
        }
        updateAndPersist { it.copy(floatingCrosshairEnabled = next) }
        syncOverlayService()
    }

    fun cycleCrosshairStyle() {
        updateAndPersist { it.copy(crosshairStyle = (it.crosshairStyle + 1) % 3) }
        syncOverlayService()
    }

    fun toggleFloatingHud() {
        val next = !_state.value.floatingHudEnabled
        if (next && !Settings.canDrawOverlays(context)) {
            _statusBannerMessage.value = "Conceda permissão de sobreposição para exibir o Medidor de Clock Flutuante."
            return
        }
        updateAndPersist { it.copy(floatingHudEnabled = next) }
        syncOverlayService()
    }

    fun selectAudioPreset(preset: AudioPreset) {
        updateAudio { it.copy(preset = preset) }
    }

    fun updateAudio(transform: (AudioSettingsState) -> AudioSettingsState) {
        updateAndPersist { s ->
            val nextAudio = transform(s.audioState)
            audioManager.applySettings(s.masterEnabled, nextAudio)
            s.copy(audioState = nextAudio)
        }
    }

    fun addForbiddenBgApp(packageName: String) {
        updateAndPersist { it.copy(forbiddenBackgroundApps = it.forbiddenBackgroundApps + packageName) }
        viewModelScope.launch {
            val res = shizukuEngine.executeWithUndo(
                id = "bg_$packageName",
                title = "Proibir segundo plano: $packageName",
                applyCommand = "cmd appops set $packageName RUN_IN_BACKGROUND ignore && am set-standby-bucket $packageName restricted",
                undoCommand = "cmd appops set $packageName RUN_IN_BACKGROUND allow && am set-standby-bucket $packageName active"
            )
            appendLog("Segundo plano bloqueado", "$packageName -> ${res.output}", res.usedShizuku, res.success)
        }
    }

    fun releaseAllForbiddenBgApps() {
        val packages = _state.value.forbiddenBackgroundApps.toList()
        updateAndPersist { it.copy(forbiddenBackgroundApps = emptySet()) }
        viewModelScope.launch {
            packages.forEach { pkg ->
                shizukuEngine.undoAction("bg_$pkg")
                    ?: shizukuEngine.runCommand("cmd appops set $pkg RUN_IN_BACKGROUND allow")
            }
            appendLog("Apps liberados", "${packages.size} apps liberados em segundo plano", shizukuStatus.value == ShizukuStatus.READY, true)
        }
    }

    fun toggleFreezeApp(packageName: String) {
        val wasFrozen = packageName in _state.value.frozenApps
        updateAndPersist { s ->
            val next = if (wasFrozen) s.frozenApps - packageName else s.frozenApps + packageName
            s.copy(frozenApps = next)
        }
        viewModelScope.launch {
            val cmd = if (wasFrozen) "pm enable $packageName" else "pm disable-user --user 0 $packageName"
            val res = shizukuEngine.runCommand(cmd)
            appendLog(if (wasFrozen) "App descongelado" else "App congelado", "$packageName: ${res.output}", res.usedShizuku, res.success)
        }
    }

    fun undoAllActiveFunctions() {
        viewModelScope.launch {
            shizukuEngine.undoAll()
            audioManager.resetAudioEffects()
            FloatingHudService.updateOverlay(context, false, false, 0, currentAccentArgb())
            updateAndPersist {
                it.copy(
                    enabledFeatureIds = emptySet(),
                    weakChipHelpActive = false,
                    lockedFpsEnabled = false,
                    uiVulkanEnabled = false,
                    floatingCrosshairEnabled = false,
                    floatingHudEnabled = false,
                    audioState = AudioSettingsState()
                )
            }
            appendLog("Desfazer tudo", "Todas as funções ativas revertidas", true, true)
            _statusBannerMessage.value = "Todas as funções ativas foram desfeitas."
        }
    }

    fun selectTheme(index: Int) {
        updateAndPersist { it.copy(selectedThemeIndex = index.coerceIn(0, MasterVoidThemes.size - 1)) }
        syncOverlayService()
    }

    fun toggleAnimateBanner() {
        updateAndPersist { it.copy(animateBanner = !it.animateBanner) }
    }

    fun toggleHapticOnTap() {
        updateAndPersist { it.copy(hapticOnTap = !it.hapticOnTap) }
    }

    fun setLanguage(lang: AppLanguage) {
        updateAndPersist { it.copy(language = lang) }
    }

    fun toggleLighterMasterVoid() {
        updateAndPersist { it.copy(lighterMasterVoid = !it.lighterMasterVoid) }
    }

    fun toggleSensitiveAppsPause() {
        updateAndPersist { it.copy(sensitiveAppsPauseEnabled = !it.sensitiveAppsPauseEnabled) }
    }

    fun toggleMasterProtection() {
        updateAndPersist { it.copy(masterProtectionEnabled = !it.masterProtectionEnabled) }
    }

    fun runDiagnosticSlowness(): String {
        val snap = _telemetry.value
        val issues = mutableListOf<String>()
        if (snap.batteryTempC >= 40f) issues += "• Temperatura alta (${snap.batteryTempC}°C): risco de thermal throttling."
        if (snap.ramFreeMb < 1200L) issues += "• RAM livre baixa (${snap.ramFreeMb} MB): recomenda-se limpar cache e proibir apps em fundo."
        if (shizukuStatus.value != ShizukuStatus.READY) issues += "• Shizuku não conectado: otimizações profundas via shell aguardando permissão."
        if (_state.value.forbiddenBackgroundApps.isEmpty()) issues += "• Nenhum app proibido em segundo plano configurado."
        if (issues.isEmpty()) issues += "• Sistema saudável! Temperaturas (${snap.batteryTempC}°C) e memória (${snap.ramFreeMb} MB livres) em faixa ideal."
        return issues.joinToString("\n")
    }

    fun executeSettingsEditor(namespace: String, key: String, value: String?, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val cmd = when {
                namespace == "props" && value.isNullOrBlank() -> "getprop $key"
                namespace == "props" && !value.isNullOrBlank() -> "setprop $key $value"
                value.isNullOrBlank() -> "settings get $namespace $key"
                else -> "settings put $namespace $key $value"
            }
            val res = shizukuEngine.runCommand(cmd)
            appendLog("Editor ($namespace)", "$cmd -> ${res.output}", res.usedShizuku, res.success)
            onResult(res.output)
        }
    }

    fun executeRepairRestrictions(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val res = shizukuEngine.runCommand(
                "settings delete global hidden_api_policy; settings put global window_animation_scale 1.0; wm size reset; wm density reset"
            )
            appendLog("Reparar restrições", res.output, res.usedShizuku, res.success)
            onResult(res.output)
        }
    }

    fun runMasterScript(script: MasterScriptItem, onOutput: (String) -> Unit) {
        viewModelScope.launch {
            val res = if (script.undoCommand.isNotBlank()) {
                shizukuEngine.executeWithUndo(
                    id = script.id,
                    title = script.title,
                    applyCommand = script.command,
                    undoCommand = script.undoCommand,
                    timeoutSeconds = script.timeoutSeconds
                )
            } else {
                shizukuEngine.runCommand(script.command, script.timeoutSeconds)
            }
            _state.update { it.copy(lastCommandOutput = res.output) }
            appendLog("Script: ${script.title}", res.output, res.usedShizuku, res.success)
            onOutput(res.output)
        }
    }

    fun undoMasterScript(script: MasterScriptItem, onOutput: (String) -> Unit) {
        viewModelScope.launch {
            val res = shizukuEngine.undoAction(script.id)
                ?: if (script.undoCommand.isNotBlank()) shizukuEngine.runCommand(script.undoCommand, script.timeoutSeconds) else null
            val out = res?.output ?: "Script sem ação reversa necessária."
            _state.update { it.copy(lastCommandOutput = out) }
            appendLog("Desfazer Script: ${script.title}", out, res?.usedShizuku ?: false, res?.success ?: true)
            onOutput(out)
        }
    }

    private suspend fun reapplyActiveShizukuFeatures() {
        val activeIds = _state.value.enabledFeatureIds
        for (id in activeIds) {
            val meta = MasterVoidCatalog.allFeatures.find { it.id == id }
            if (meta != null && meta.applyCmd.isNotBlank()) {
                shizukuEngine.executeWithUndo(meta.id, meta.title, meta.applyCmd, meta.undoCmd)
            }
        }
    }

    private fun syncOverlayService() {
        val s = _state.value
        FloatingHudService.updateOverlay(
            context = context,
            showHud = s.masterEnabled && s.floatingHudEnabled,
            showCrosshair = s.masterEnabled && s.floatingCrosshairEnabled,
            crosshairStyle = s.crosshairStyle,
            accentColorInt = currentAccentArgb()
        )
    }

    private fun currentAccentArgb(): Int {
        return MasterVoidThemes.getOrElse(_state.value.selectedThemeIndex) { MasterVoidThemes[0] }
            .primary.toArgb()
    }

    private fun appendLog(title: String, detail: String, usedShizuku: Boolean, success: Boolean) {
        val entry = ActivityLogEntry(
            timeLabel = timeFormat.format(Date()),
            title = title,
            detail = detail.take(180),
            usedShizuku = usedShizuku,
            success = success
        )
        _state.update { s ->
            s.copy(activityLogs = (listOf(entry) + s.activityLogs).take(60))
        }
    }

    private fun updateAndPersist(transform: (MasterVoidState) -> MasterVoidState) {
        val updated = transform(_state.value)
        _state.value = updated
        viewModelScope.launch {
            preferences.saveState(updated)
        }
    }

    override fun onCleared() {
        super.onCleared()
        dpiCountdownJob?.cancel()
        shizukuEngine.release()
        audioManager.release()
    }
}
