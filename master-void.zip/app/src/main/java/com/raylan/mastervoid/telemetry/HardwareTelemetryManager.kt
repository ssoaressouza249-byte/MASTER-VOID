package com.raylan.mastervoid.telemetry

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.hardware.display.DisplayManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

enum class TempBadge(val label: String) {
    COLD("Frio"),
    WARM("Morno"),
    HOT("Quente")
}

data class HardwareTelemetry(
    val deviceModel: String = Build.MODEL,
    val manufacturer: String = Build.MANUFACTURER,
    val gpuName: String = "Adreno / Mali GPU",
    val currentRefreshHz: Int = 60,
    val supportedRefreshHz: List<Int> = listOf(60),
    val androidVersionLabel: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
    val ramTotalMb: Long = 0L,
    val ramFreeMb: Long = 0L,
    val chipSoc: String = Build.HARDWARE,
    val batteryTempC: Float = 28.0f,
    val batteryPercent: Int = 100,
    val tempBadge: TempBadge = TempBadge.COLD,
    val densityDpi: Int = 420,
    val screenResolution: String = "1080x2400"
)

data class InstalledAppItem(
    val packageName: String,
    val label: String,
    val isGame: Boolean,
    val isSystemApp: Boolean
)

class HardwareTelemetryManager(private val context: Context) {

    @Volatile
    private var cachedGpuName: String? = null

    fun collectSnapshot(): HardwareTelemetry {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val freeMb = memInfo.availMem / (1024L * 1024L)

        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val currentHz = display?.mode?.refreshRate?.roundToInt() ?: 60
        val supportedHz = display?.supportedModes
            ?.map { it.refreshRate.roundToInt() }
            ?.distinct()
            ?.sorted()
            ?: listOf(currentHz)

        val dm = context.resources.displayMetrics
        val resolution = "${dm.widthPixels}x${dm.heightPixels}"
        val density = dm.densityDpi

        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val rawTemp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 280) ?: 280
        val tempC = rawTemp / 10f
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100)?.coerceAtLeast(1) ?: 100
        val pct = ((level * 100f) / scale).roundToInt()

        val badge = when {
            tempC < 34.0f -> TempBadge.COLD
            tempC <= 40.0f -> TempBadge.WARM
            else -> TempBadge.HOT
        }

        val soc = resolveSocName()
        val gpu = resolveGpuName()

        return HardwareTelemetry(
            deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
            manufacturer = Build.MANUFACTURER,
            gpuName = gpu,
            currentRefreshHz = currentHz,
            supportedRefreshHz = supportedHz,
            androidVersionLabel = "Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}",
            ramTotalMb = totalMb,
            ramFreeMb = freeMb,
            chipSoc = soc,
            batteryTempC = tempC,
            batteryPercent = pct,
            tempBadge = badge,
            densityDpi = density,
            screenResolution = resolution
        )
    }

    suspend fun getInstalledApps(includeSystem: Boolean = false): List<InstalledAppItem> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            apps.asSequence()
                .filter { app ->
                    val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val hasLaunchIntent = pm.getLaunchIntentForPackage(app.packageName) != null
                    hasLaunchIntent && (includeSystem || !isSystem) && app.packageName != context.packageName
                }
                .map { app ->
                    val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val isGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        app.category == ApplicationInfo.CATEGORY_GAME
                    } else {
                        @Suppress("DEPRECATION")
                        (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                    }
                    InstalledAppItem(
                        packageName = app.packageName,
                        label = pm.getApplicationLabel(app).toString(),
                        isGame = isGame,
                        isSystemApp = isSystem
                    )
                }
                .sortedWith(compareByDescending<InstalledAppItem> { it.isGame }.thenBy { it.label.lowercase() })
                .toList()
        }

    fun loadAppIcon(packageName: String): Drawable? {
        return runCatching {
            context.packageManager.getApplicationIcon(packageName)
        }.getOrNull()
    }

    private fun resolveSocName(): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val model = Build.SOC_MODEL
            if (!model.isNullOrBlank() && model != Build.UNKNOWN) {
                return model
            }
        }
        val cpuInfoHardware = runCatching {
            File("/proc/cpuinfo").takeIf { it.canRead() }?.readLines()
                ?.firstOrNull { it.startsWith("Hardware", ignoreCase = true) }
                ?.substringAfter(":")
                ?.trim()
        }.getOrNull()
        return cpuInfoHardware?.takeIf { it.isNotBlank() } ?: Build.HARDWARE
    }

    private fun resolveGpuName(): String {
        cachedGpuName?.let { return it }

        val kgslModel = runCatching {
            File("/sys/class/kgsl/kgsl-3d0/gpu_model")
                .takeIf { it.canRead() }
                ?.readText()
                ?.trim()
        }.getOrNull()
        if (!kgslModel.isNullOrBlank()) {
            cachedGpuName = kgslModel
            return kgslModel
        }

        val eglRenderer = queryEglRenderer()
        if (!eglRenderer.isNullOrBlank()) {
            cachedGpuName = eglRenderer
            return eglRenderer
        }

        val prop = readSystemProperty("ro.hardware.egl")
            .ifBlank { readSystemProperty("ro.hardware.vulkan") }
            .ifBlank { Build.BOARD }
        cachedGpuName = prop
        return prop
    }

    private fun queryEglRenderer(): String? {
        return runCatching {
            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) return null
            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) return null
            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0)
            val config = configs.firstOrNull() ?: return null
            val surfAttribs = intArrayOf(
                EGL14.EGL_WIDTH, 1,
                EGL14.EGL_HEIGHT, 1,
                EGL14.EGL_NONE
            )
            val surface = EGL14.eglCreatePbufferSurface(display, config, surfAttribs, 0)
            val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            val context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
            EGL14.eglMakeCurrent(display, surface, surface, context)
            val renderer = GLES20.glGetString(GLES20.GL_RENDERER)
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surface)
            EGL14.eglDestroyContext(display, context)
            EGL14.eglTerminate(display)
            renderer
        }.getOrNull()
    }

    private fun readSystemProperty(key: String): String {
        return runCatching {
            val clazz = Class.forName("android.os.SystemProperties")
            val get = clazz.getMethod("get", String::class.java, String::class.java)
            get.invoke(null, key, "") as? String ?: ""
        }.getOrDefault("")
    }
}
