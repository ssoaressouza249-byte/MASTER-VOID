package com.raylan.mastervoid.ui.screens

import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.mastervoid.audio.AudioPreset
import com.raylan.mastervoid.model.AddedGameItem
import com.raylan.mastervoid.model.GameSubTab
import com.raylan.mastervoid.model.HzAppRule
import com.raylan.mastervoid.model.MasterVoidCatalog
import com.raylan.mastervoid.model.MasterVoidState
import com.raylan.mastervoid.telemetry.InstalledAppItem
import com.raylan.mastervoid.ui.components.AppIconImage
import com.raylan.mastervoid.ui.components.AppPickerDialog
import com.raylan.mastervoid.ui.components.MasterVoidFooter
import com.raylan.mastervoid.ui.components.TouchTester120HzDialog
import com.raylan.mastervoid.ui.components.VoidCardContainer
import com.raylan.mastervoid.ui.components.VoidFeatureToggleRow
import com.raylan.mastervoid.ui.components.VoidOptionChipRow
import com.raylan.mastervoid.ui.components.VoidSectionHeader
import com.raylan.mastervoid.ui.theme.VoidAmber
import com.raylan.mastervoid.ui.theme.VoidBorder
import com.raylan.mastervoid.ui.theme.VoidCard
import com.raylan.mastervoid.ui.theme.VoidCardElevated
import com.raylan.mastervoid.ui.theme.VoidGreen
import com.raylan.mastervoid.ui.theme.VoidTextMuted
import com.raylan.mastervoid.ui.theme.VoidTextPrimary
import com.raylan.mastervoid.ui.theme.VoidTextSecondary
import com.raylan.mastervoid.viewmodel.MasterVoidViewModel
import kotlin.math.roundToInt

@Composable
fun GameScreen(
    state: MasterVoidState,
    installedApps: List<InstalledAppItem>,
    selectedSubTab: GameSubTab,
    onSelectSubTab: (GameSubTab) -> Unit,
    viewModel: MasterVoidViewModel
) {
    val context = LocalContext.current
    var showAddGameDialog by remember { mutableStateOf(false) }
    var showHzAppDialog by remember { mutableStateOf(false) }
    var showPerGameGraphDialog by remember { mutableStateOf(false) }
    var showDpiPickerDialog by remember { mutableStateOf(false) }
    var showTouchTester by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // 5 Sub-tabs bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GameSubTab.entries.forEach { tab ->
                val selected = tab == selectedSubTab
                Surface(
                    onClick = { onSelectSubTab(tab) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else VoidCard,
                    border = BorderStroke(
                        1.dp,
                        if (selected) MaterialTheme.colorScheme.primary else VoidBorder
                    ),
                    modifier = Modifier.testTag("game_subtab_${tab.name.lowercase()}")
                ) {
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) MaterialTheme.colorScheme.secondary else VoidTextSecondary,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedSubTab) {
                GameSubTab.GAMES_ENGINE -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            VoidSectionHeader(
                                title = "Meus jogos",
                                subtitle = "${state.addedGames.size} adicionados"
                            )
                            Button(
                                onClick = {
                                    viewModel.refreshInstalledApps(false)
                                    showAddGameDialog = true
                                },
                                modifier = Modifier.testTag("add_game_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = "Adicionar jogo", modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Adicionar")
                            }
                        }
                    }

                    if (state.addedGames.isEmpty()) {
                        item {
                            VoidCardContainer {
                                Text(
                                    text = "Nenhum jogo adicionado ainda. Toque em + Adicionar para vincular seus jogos instalados com Play direto.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = VoidTextSecondary
                                )
                            }
                        }
                    } else {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                state.addedGames.chunked(2).forEach { rowGames ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        rowGames.forEach { game ->
                                            GameGridCard(
                                                game = game,
                                                icon = remember(game.packageName) { viewModel.loadAppIcon(game.packageName) },
                                                onPlay = { viewModel.launchGame(game) },
                                                onRemove = { viewModel.removeGame(game.packageName) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        if (rowGames.size == 1) {
                                            Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        VoidSectionHeader(
                            title = "Motor inteligente",
                            subtitle = "Automação contextual de desempenho"
                        )
                    }
                    val engineIds = listOf("auto_detect", "smart_detect", "game_only", "app_support", "ia_master", "fps_adaptive")
                    items(engineIds.size) { idx ->
                        FeatureByIdRow(engineIds[idx], state, viewModel)
                    }
                }

                GameSubTab.PERFORMANCE -> {
                    item {
                        VoidSectionHeader(
                            title = "Switches de Desempenho",
                            subtitle = "Estabilidade de CPU, driver gráfico e GameMode"
                        )
                    }
                    val perfIds = listOf(
                        "perf_mode", "check_game_mode", "lag_detector",
                        "updated_driver", "keep_screen_on", "soc_profile", "genre_profile"
                    )
                    items(perfIds.size) { idx ->
                        FeatureByIdRow(perfIds[idx], state, viewModel)
                    }

                    item {
                        VoidCardContainer(highlighted = true) {
                            VoidSectionHeader(
                                title = "IA Master • um cérebro só",
                                badge = "PREDITIVO"
                            )
                            Spacer(Modifier.height(8.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                FeatureByIdRow("ia_learn_game", state, viewModel)
                                FeatureByIdRow("ia_live_pilot", state, viewModel)
                                FeatureByIdRow("ia_drop_forecast", state, viewModel)
                            }
                        }
                    }

                    item {
                        VoidCardContainer {
                            VoidSectionHeader(
                                title = "Resolução e FPS",
                                subtitle = "Escala de renderização e caminho gráfico"
                            )
                            Spacer(Modifier.height(10.dp))
                            VoidOptionChipRow(
                                label = "Resolução do jogo",
                                options = listOf("Auto", "100%", "90%", "80%", "70%", "60%"),
                                selectedOption = state.gameResolutionScale,
                                onSelect = { viewModel.setGameResolutionScale(it) },
                                hapticEnabled = state.hapticOnTap
                            )
                            Spacer(Modifier.height(10.dp))
                            VoidOptionChipRow(
                                label = "FPS do jogo",
                                options = listOf("Auto", "30", "45", "60", "90"),
                                selectedOption = state.gameTargetFps,
                                onSelect = { viewModel.setGameTargetFps(it) },
                                hapticEnabled = state.hapticOnTap
                            )
                            Spacer(Modifier.height(10.dp))
                            VoidFeatureToggleRow(
                                featureId = "stretched_fov",
                                title = "Tela do Jogo (Visão Esticada / FOV)",
                                subtitle = "Amplia campo de visão lateral durante partidas compatíveis",
                                checked = state.stretchedGameScreen,
                                onCheckedChange = { viewModel.toggleStretchedScreen() },
                                hapticEnabled = state.hapticOnTap
                            )
                            Spacer(Modifier.height(10.dp))
                            VoidOptionChipRow(
                                label = "Caminho gráfico",
                                options = listOf("Auto", "Original", "Driver", "Teste", "ANGLE", "Modo Jogo"),
                                selectedOption = state.graphicPath,
                                onSelect = { viewModel.setGraphicPath(it) },
                                hapticEnabled = state.hapticOnTap
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { showPerGameGraphDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Ver gráfico de cada jogo")
                            }
                        }
                    }

                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = VoidAmber.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.5.dp, VoidAmber)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.WarningAmber,
                                    contentDescription = "Ajuda pra Chip Fraco",
                                    tint = VoidAmber,
                                    modifier = Modifier.size(30.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Ajuda pra Chip Fraco",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = VoidAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Reduz animações, limpa RAM e remove desfoques para chips de entrada.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = VoidTextPrimary
                                    )
                                }
                                Button(
                                    onClick = { viewModel.toggleWeakChipHelp() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = VoidAmber,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("weak_chip_button")
                                ) {
                                    Text(
                                        text = if (state.weakChipHelpActive) "Ligada" else "Ligar a ajuda",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                GameSubTab.SCREEN_IMAGE -> {
                    item {
                        VoidSectionHeader(
                            title = "Tela e Fluidez",
                            subtitle = "Controle de taxa de atualização e composição"
                        )
                    }
                    val screenIds = listOf("hz_max", "no_blur", "light_anim", "light_home", "hz_adaptive", "auto_hz_profile")
                    items(screenIds.size) { idx ->
                        FeatureByIdRow(screenIds[idx], state, viewModel)
                    }

                    item {
                        VoidCardContainer {
                            VoidSectionHeader(
                                title = "Hz por App",
                                badge = "${state.hzAppPackages.size} apps"
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Regra de taxa",
                                options = HzAppRule.entries.map { it.label },
                                selectedOption = state.hzPerAppRule.label,
                                onSelect = { label ->
                                    HzAppRule.entries.find { it.label == label }?.let { viewModel.setHzAppRule(it) }
                                }
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        viewModel.refreshInstalledApps(false)
                                        showHzAppDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("+ Escolher")
                                }
                                OutlinedButton(
                                    onClick = { viewModel.clearHzApps() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Limpar")
                                }
                            }
                            if (state.hzAppPackages.isNotEmpty()) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = state.hzAppPackages.joinToString(", "),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VoidTextSecondary
                                )
                            }
                        }
                    }

                    item {
                        VoidCardContainer {
                            VoidSectionHeader(
                                title = "FPS cravado no sistema",
                                badge = if (state.lockedFpsEnabled) "LIGADO" else "DESLIGADO"
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidFeatureToggleRow(
                                featureId = "locked_fps_switch",
                                title = "Cravado: ${if (state.lockedFpsEnabled) "Ligado" else "Desligado"}",
                                subtitle = "Trava atualização mínima/máxima via Settings System",
                                checked = state.lockedFpsEnabled,
                                onCheckedChange = { viewModel.toggleLockedFps() }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidFeatureToggleRow(
                                featureId = "ui_vulkan_switch",
                                title = "UI por Vulkan",
                                subtitle = "Renderiza interface HWUI utilizando backend SkiaVulkan",
                                checked = state.uiVulkanEnabled,
                                onCheckedChange = { viewModel.toggleUiVulkan() }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Alvo",
                                options = listOf("60 Hz", "90 Hz", "120 Hz"),
                                selectedOption = state.lockedFpsTarget,
                                onSelect = { viewModel.setLockedFpsTarget(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Modo",
                                options = listOf("Travado", "Teto", "Por jogo"),
                                selectedOption = state.lockedFpsMode,
                                onSelect = { viewModel.setLockedFpsMode(it) }
                            )
                        }
                    }

                    item {
                        VoidCardContainer {
                            VoidSectionHeader(title = "Gráficos & Imagem no jogo")
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Cores Vivas",
                                options = listOf("Desligado", "1.1", "1.2", "1.3", "1.4", "1.5"),
                                selectedOption = state.vividColorsLevel,
                                onSelect = { viewModel.setVividColors(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Perfil de Cor do Jogo",
                                options = listOf("Natural", "Realçado", "Saturado"),
                                selectedOption = state.gameColorProfile,
                                onSelect = { viewModel.setGameColorProfile(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Visão no Escuro",
                                options = listOf("Desligado", "1", "2", "3"),
                                selectedOption = state.darkVisionLevel,
                                onSelect = { viewModel.setDarkVision(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Contraste Forte",
                                options = listOf("Desligado", "1.1", "1.15", "1.2", "1.3"),
                                selectedOption = state.strongContrastLevel,
                                onSelect = { viewModel.setStrongContrast(it) }
                            )
                            Spacer(Modifier.height(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                FeatureByIdRow("angle_renderer", state, viewModel)
                                FeatureByIdRow("hd_mode", state, viewModel)
                                FeatureByIdRow("true_colors", state, viewModel)
                                FeatureByIdRow("max_screen_res", state, viewModel)
                            }
                        }
                    }
                }

                GameSubTab.TOUCH_AIM -> {
                    item {
                        VoidSectionHeader(
                            title = "Resposta de Toque & Estabilidade",
                            subtitle = "Precisão tátil e eliminação de atrasos"
                        )
                    }
                    val touchIds = listOf(
                        "free_edges", "fixed_nav", "locked_rotation", "no_vibration",
                        "light_match_mode", "zero_anim", "pointer_speed_boost", "touch_sensitive"
                    )
                    items(touchIds.size) { idx ->
                        FeatureByIdRow(touchIds[idx], state, viewModel)
                    }

                    item {
                        VoidCardContainer(highlighted = state.dpiTestState.isTesting) {
                            VoidSectionHeader(
                                title = "DPI Personalizado (wm density)",
                                badge = "${state.currentDpi} DPI"
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Atual: ${state.currentDpi} DPI  •  Original: ${state.originalDpi} DPI",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            if (state.dpiTestState.isTesting) {
                                Spacer(Modifier.height(10.dp))
                                Surface(
                                    color = VoidAmber.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, VoidAmber)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "Testando ${state.dpiTestState.targetDpi} DPI — Reverte automaticamente em ${state.dpiTestState.secondsRemaining}s",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = VoidAmber,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = { viewModel.keepTestedDpi() },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Manter")
                                            }
                                            OutlinedButton(
                                                onClick = { viewModel.revertDpiToOriginal() },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Reverter")
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showDpiPickerDialog = true },
                                    modifier = Modifier.weight(1f).testTag("choose_dpi_button"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Escolher DPI")
                                }
                                OutlinedButton(
                                    onClick = { viewModel.revertDpiToOriginal() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Original")
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            VoidFeatureToggleRow(
                                featureId = "protect_res",
                                title = "Proteger minha resolução",
                                subtitle = "Impede alterações acidentais fora da janela de teste de 15s",
                                checked = state.protectResolution,
                                onCheckedChange = { viewModel.toggleProtectResolution() }
                            )
                        }
                    }

                    item {
                        VoidCardContainer {
                            VoidSectionHeader(title = "Tempo do toque & Ponteiro")
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Toque Longo Ajustável (ms)",
                                options = listOf("Padrão", "150", "200", "250", "300", "400"),
                                selectedOption = state.longPressMs,
                                onSelect = { viewModel.setLongPressMs(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Toque Duplo Ajustável (ms)",
                                options = listOf("Padrão", "150", "200", "250", "300"),
                                selectedOption = state.doubleTapMs,
                                onSelect = { viewModel.setDoubleTapMs(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Velocidade do ponteiro",
                                options = listOf("-3", "0", "+3", "+5", "+7"),
                                selectedOption = state.pointerSpeed,
                                onSelect = { viewModel.setPointerSpeed(it) }
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Quando age",
                                options = listOf("Sempre", "Só no jogo"),
                                selectedOption = state.touchWhenActive,
                                onSelect = { viewModel.setTouchWhenActive(it) }
                            )
                        }
                    }

                    item {
                        VoidCardContainer {
                            VoidSectionHeader(title = "Mira Flutuante & Testador 120Hz")
                            Spacer(Modifier.height(8.dp))
                            VoidFeatureToggleRow(
                                featureId = "floating_crosshair",
                                title = "Mira Flutuante",
                                subtitle = "Exibe retículo central sobreposto sem bloquear toques",
                                checked = state.floatingCrosshairEnabled,
                                onCheckedChange = {
                                    if (!Settings.canDrawOverlays(context)) {
                                        context.startActivity(
                                            Intent(
                                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                Uri.parse("package:${context.packageName}")
                                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    } else {
                                        viewModel.toggleFloatingCrosshair()
                                    }
                                }
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { viewModel.cycleCrosshairStyle() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Filled.CenterFocusStrong, contentDescription = "Estilo da mira", modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Estilo #${state.crosshairStyle + 1}")
                                }
                                Button(
                                    onClick = { showTouchTester = true },
                                    modifier = Modifier.weight(1f).testTag("touch_tester_button"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Filled.TouchApp, contentDescription = "Testador 120Hz", modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Testar 120Hz")
                                }
                            }
                        }
                    }
                }

                GameSubTab.SOUND -> {
                    item {
                        VoidCardContainer {
                            VoidSectionHeader(
                                title = "Perfis de Áudio (Equalizer & DSP)",
                                badge = state.audioState.preset.label
                            )
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Preset ativo",
                                options = AudioPreset.entries.map { it.label },
                                selectedOption = state.audioState.preset.label,
                                onSelect = { label ->
                                    AudioPreset.entries.find { it.label == label }?.let { viewModel.selectAudioPreset(it) }
                                }
                            )
                        }
                    }

                    item {
                        val audio = state.audioState
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            VoidFeatureToggleRow(
                                "audio_steps", "Passos Altos", "Realça médios-agudos para localizar inimigos",
                                audio.loudSteps, { v -> viewModel.updateAudio { it.copy(loudSteps = v, preset = AudioPreset.CUSTOM) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_bass", "Graves Fortes", "Reforço BassBoost para explosões e impacto",
                                audio.strongBass, { v -> viewModel.updateAudio { it.copy(strongBass = v, preset = AudioPreset.CUSTOM) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_highs", "Agudos Cristalinos", "Clareza em tiros, recargas e detalhes espaciais",
                                audio.crystalHighs, { v -> viewModel.updateAudio { it.copy(crystalHighs = v, preset = AudioPreset.CUSTOM) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_voice", "Clareza de Voz", "Prioriza frequências vocais de call em equipe",
                                audio.voiceClarity, { v -> viewModel.updateAudio { it.copy(voiceClarity = v, preset = AudioPreset.CUSTOM) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_extra", "Volume Extra (+6 dB)", "Aplica LoudnessEnhancer seguro de +600 mB",
                                audio.extraVolume6Db, { v -> viewModel.updateAudio { it.copy(extraVolume6Db = v) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_comp", "Compressor", "Nivela picos altos e eleva sons sutis",
                                audio.compressor, { v -> viewModel.updateAudio { it.copy(compressor = v) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_3d", "Som 3D no Fone", "Ativa Virtualizer estéreo espacial para fones",
                                audio.spatial3dHeadset, { v -> viewModel.updateAudio { it.copy(spatial3dHeadset = v) } }
                            )
                            VoidFeatureToggleRow(
                                "audio_clean_bass", "Graves Limpos", "Controla sub-graves sem abafar passos",
                                audio.cleanBass, { v -> viewModel.updateAudio { it.copy(cleanBass = v) } }
                            )
                        }
                    }

                    item {
                        val audio = state.audioState
                        VoidCardContainer {
                            VoidSectionHeader(title = "Volume e silêncio")
                            Spacer(Modifier.height(8.dp))
                            VoidOptionChipRow(
                                label = "Volume Automático",
                                options = listOf("Desligado", "50%", "70%", "85%", "100%"),
                                selectedOption = audio.autoVolumePercent?.let { "$it%" } ?: "Desligado",
                                onSelect = { opt ->
                                    val pct = opt.filter { it.isDigit() }.toIntOrNull()
                                    viewModel.updateAudio { it.copy(autoVolumePercent = pct) }
                                }
                            )
                            Spacer(Modifier.height(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                VoidFeatureToggleRow(
                                    "audio_mute_sys", "Sem Sons do Sistema", "Silencia cliques e alertas do sistema na partida",
                                    audio.muteSystemSounds, { v -> viewModel.updateAudio { it.copy(muteSystemSounds = v) } }
                                )
                                VoidFeatureToggleRow(
                                    "audio_exclusivity", "Exclusividade de Áudio", "Solicita AudioFocus exclusivo para o jogo",
                                    audio.audioExclusivity, { v -> viewModel.updateAudio { it.copy(audioExclusivity = v) } }
                                )
                                VoidFeatureToggleRow(
                                    "audio_bt_ll", "Bluetooth Sem Atraso", "Ativa hint de baixa latência A2DP no áudio",
                                    audio.bluetoothLowLatency, { v -> viewModel.updateAudio { it.copy(bluetoothLowLatency = v) } }
                                )
                            }
                        }
                    }
                }
            }

            item {
                MasterVoidFooter()
            }
        }
    }

    if (showAddGameDialog) {
        AppPickerDialog(
            title = "Adicionar jogo em Meus jogos",
            apps = installedApps,
            loadIcon = viewModel::loadAppIcon,
            onSelect = { app ->
                viewModel.addGame(app)
                showAddGameDialog = false
            },
            onDismiss = { showAddGameDialog = false }
        )
    }

    if (showHzAppDialog) {
        AppPickerDialog(
            title = "Escolher app para regra de Hz",
            apps = installedApps,
            loadIcon = viewModel::loadAppIcon,
            onSelect = { app ->
                viewModel.addHzApp(app.packageName)
                showHzAppDialog = false
            },
            onDismiss = { showHzAppDialog = false }
        )
    }

    if (showPerGameGraphDialog) {
        AlertDialog(
            onDismissRequest = { showPerGameGraphDialog = false },
            containerColor = VoidCard,
            title = { Text("Gráfico de cada jogo", color = VoidTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (state.addedGames.isEmpty()) {
                        Text(
                            "Adicione jogos em 'Jogos e Motor' para visualizar o caminho gráfico por pacote.",
                            color = VoidTextSecondary
                        )
                    } else {
                        state.addedGames.forEach { game ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(game.name, color = VoidTextPrimary, modifier = Modifier.weight(1f))
                                Text(
                                    "${state.graphicPath} • ${state.gameResolutionScale}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPerGameGraphDialog = false }) {
                    Text("Fechar", color = MaterialTheme.colorScheme.secondary)
                }
            }
        )
    }

    if (showDpiPickerDialog) {
        var sliderDpi by remember { mutableIntStateOf(state.currentDpi.coerceIn(100, 450)) }
        AlertDialog(
            onDismissRequest = { showDpiPickerDialog = false },
            containerColor = VoidCard,
            title = { Text("Escolher DPI (100 a 450)", color = VoidTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "DPI selecionado: $sliderDpi (teste automático de 15 segundos)",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Slider(
                        value = sliderDpi.toFloat(),
                        onValueChange = { sliderDpi = it.roundToInt() },
                        valueRange = 100f..450f
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(240, 320, 380, 420, 450).forEach { preset ->
                            Surface(
                                onClick = { sliderDpi = preset },
                                shape = RoundedCornerShape(8.dp),
                                color = if (sliderDpi == preset) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else VoidCardElevated,
                                border = BorderStroke(1.dp, VoidBorder)
                            ) {
                                Text(
                                    text = "$preset",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VoidTextPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showDpiPickerDialog = false
                    viewModel.startDpiTest(sliderDpi)
                }) {
                    Text("Testar 15s")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDpiPickerDialog = false }) {
                    Text("Cancelar", color = VoidTextSecondary)
                }
            }
        )
    }

    if (showTouchTester) {
        TouchTester120HzDialog(onDismiss = { showTouchTester = false })
    }
}

@Composable
private fun FeatureByIdRow(
    featureId: String,
    state: MasterVoidState,
    viewModel: MasterVoidViewModel
) {
    val meta = remember(featureId) { MasterVoidCatalog.allFeatures.find { it.id == featureId } } ?: return
    VoidFeatureToggleRow(
        featureId = meta.id,
        title = meta.title,
        subtitle = meta.subtitle,
        checked = meta.id in state.enabledFeatureIds,
        onCheckedChange = { viewModel.toggleFeature(meta.id) },
        isFavorite = meta.id in state.favoriteFeatureIds,
        onFavoriteToggle = { viewModel.toggleFavorite(meta.id) },
        hapticEnabled = state.hapticOnTap
    )
}

@Composable
private fun GameGridCard(
    game: AddedGameItem,
    icon: Drawable?,
    onPlay: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    VoidCardContainer(modifier = modifier, highlighted = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIconImage(
                drawable = icon,
                contentDescription = game.name,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = game.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = VoidTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${game.playTimeMinutes} min jogados",
                    style = MaterialTheme.typography.labelSmall,
                    color = VoidTextMuted
                )
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = "Remover ${game.name}",
                    tint = VoidTextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onPlay,
            modifier = Modifier.fillMaxWidth().height(38.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            )
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = "Jogar", modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Play direto", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        }
    }
}
