package com.raylan.mastervoid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.mastervoid.ui.MasterVoidApp
import com.raylan.mastervoid.ui.screens.SecurityBlockScreen
import com.raylan.mastervoid.ui.theme.MasterVoidTheme
import com.raylan.mastervoid.viewmodel.MasterVoidViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MasterVoidViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        viewModel.reverifySecurity()

        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val securityStatus by viewModel.securityStatus.collectAsStateWithLifecycle()

            MasterVoidTheme(themeIndex = state.selectedThemeIndex) {
                if (!securityStatus.isIntact) {
                    LaunchedEffect(securityStatus) {
                        viewModel.triggerSecurityUninstall()
                    }
                    SecurityBlockScreen(
                        securityStatus = securityStatus,
                        onUninstallClick = { viewModel.triggerSecurityUninstall() }
                    )
                } else {
                    MasterVoidApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.reverifySecurity()
    }
}
