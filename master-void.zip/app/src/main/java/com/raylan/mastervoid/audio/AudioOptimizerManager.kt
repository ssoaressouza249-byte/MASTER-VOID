package com.raylan.mastervoid.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import kotlin.math.roundToInt

enum class AudioPreset(val label: String) {
    FPS_STEPS("Passos FPS"),
    VOICE("Voz"),
    CINEMA("Cinema"),
    HEADSET("Fone"),
    OFF("Desligado"),
    CUSTOM("Personalizado")
}

data class AudioSettingsState(
    val preset: AudioPreset = AudioPreset.OFF,
    val loudSteps: Boolean = false,
    val strongBass: Boolean = false,
    val crystalHighs: Boolean = false,
    val voiceClarity: Boolean = false,
    val extraVolume6Db: Boolean = false,
    val compressor: Boolean = false,
    val spatial3dHeadset: Boolean = false,
    val cleanBass: Boolean = false,
    val autoVolumePercent: Int? = null,
    val muteSystemSounds: Boolean = false,
    val audioExclusivity: Boolean = false,
    val bluetoothLowLatency: Boolean = false
)

class AudioOptimizerManager(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var focusRequest: AudioFocusRequest? = null

    fun applySettings(masterActive: Boolean, state: AudioSettingsState) {
        if (!masterActive || state.preset == AudioPreset.OFF && !hasAnyActiveEffect(state)) {
            resetAudioEffects()
            return
        }

        ensureEffectsInitialized()

        // Equalizer 5-band tuning (millibels)
        equalizer?.let { eq ->
            runCatching {
                eq.enabled = true
                val bands = eq.numberOfBands.toInt()
                val minLevel = eq.bandLevelRange[0]
                val maxLevel = eq.bandLevelRange[1]
                for (band in 0 until bands) {
                    val ratio = computeBandGainRatio(band, bands, state)
                    val target = (ratio * maxLevel).roundToInt()
                        .coerceIn(minLevel.toInt(), maxLevel.toInt())
                        .toShort()
                    eq.setBandLevel(band.toShort(), target)
                }
            }
        }

        // BassBoost
        bassBoost?.let { bb ->
            runCatching {
                val strength: Short = when {
                    state.strongBass -> 800
                    state.cleanBass -> 350
                    state.preset == AudioPreset.CINEMA -> 600
                    state.preset == AudioPreset.FPS_STEPS -> 150
                    else -> 0
                }
                bb.enabled = strength > 0
                if (bb.strengthSupported && strength > 0) {
                    bb.setStrength(strength)
                }
            }
        }

        // Virtualizer (Som 3D no Fone)
        virtualizer?.let { virt ->
            runCatching {
                val strength: Short = when {
                    state.spatial3dHeadset -> 850
                    state.preset == AudioPreset.HEADSET -> 650
                    state.preset == AudioPreset.CINEMA -> 750
                    state.preset == AudioPreset.FPS_STEPS -> 500
                    else -> 0
                }
                virt.enabled = strength > 0
                if (virt.strengthSupported && strength > 0) {
                    virt.setStrength(strength)
                }
            }
        }

        // LoudnessEnhancer (+6 dB = 600 mB)
        loudnessEnhancer?.let { le ->
            runCatching {
                val gainMb = when {
                    state.extraVolume6Db && state.compressor -> 750
                    state.extraVolume6Db -> 600
                    state.compressor -> 300
                    else -> 0
                }
                le.enabled = gainMb > 0
                if (gainMb > 0) {
                    le.setTargetGain(gainMb)
                }
            }
        }

        // Auto volume percent
        state.autoVolumePercent?.let { pct ->
            runCatching {
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val targetVol = ((maxVol * pct) / 100f).roundToInt().coerceIn(0, maxVol)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
            }
        }

        // System sounds mute
        runCatching {
            val adjust = if (state.muteSystemSounds) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            audioManager.adjustStreamVolume(AudioManager.STREAM_SYSTEM, adjust, 0)
        }

        // Audio exclusivity (AudioFocus)
        if (state.audioExclusivity) {
            requestExclusiveFocus()
        } else {
            abandonExclusiveFocus()
        }

        // Low latency audio hint
        runCatching {
            val param = if (state.bluetoothLowLatency) {
                "a2dp_low_latency=true"
            } else {
                "a2dp_low_latency=false"
            }
            audioManager.setParameters(param)
        }
    }

    fun resetAudioEffects() {
        runCatching { equalizer?.enabled = false }
        runCatching { bassBoost?.enabled = false }
        runCatching { virtualizer?.enabled = false }
        runCatching { loudnessEnhancer?.enabled = false }
        runCatching {
            audioManager.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        }
        abandonExclusiveFocus()
    }

    fun release() {
        resetAudioEffects()
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
    }

    private fun ensureEffectsInitialized() {
        if (equalizer == null) {
            equalizer = runCatching { Equalizer(0, 0) }.getOrNull()
        }
        if (bassBoost == null) {
            bassBoost = runCatching { BassBoost(0, 0) }.getOrNull()
        }
        if (virtualizer == null) {
            virtualizer = runCatching { Virtualizer(0, 0) }.getOrNull()
        }
        if (loudnessEnhancer == null) {
            loudnessEnhancer = runCatching { LoudnessEnhancer(0) }.getOrNull()
        }
    }

    private fun requestExclusiveFocus() {
        if (focusRequest != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            .setAudioAttributes(attrs)
            .build()
        focusRequest = req
        runCatching { audioManager.requestAudioFocus(req) }
    }

    private fun abandonExclusiveFocus() {
        focusRequest?.let { req ->
            runCatching { audioManager.abandonAudioFocusRequest(req) }
        }
        focusRequest = null
    }

    private fun hasAnyActiveEffect(state: AudioSettingsState): Boolean {
        return state.loudSteps || state.strongBass || state.crystalHighs ||
            state.voiceClarity || state.extraVolume6Db || state.compressor ||
            state.spatial3dHeadset || state.cleanBass ||
            state.autoVolumePercent != null || state.muteSystemSounds ||
            state.audioExclusivity || state.bluetoothLowLatency
    }

    private fun computeBandGainRatio(band: Int, totalBands: Int, state: AudioSettingsState): Float {
        var gain = when (state.preset) {
            AudioPreset.FPS_STEPS -> when (band) {
                0 -> -0.25f
                1 -> 0.15f
                2 -> 0.55f
                3 -> 0.85f
                else -> 0.65f
            }
            AudioPreset.VOICE -> when (band) {
                0 -> -0.2f
                1, 2 -> 0.65f
                3 -> 0.45f
                else -> 0.15f
            }
            AudioPreset.CINEMA -> when (band) {
                0 -> 0.65f
                1 -> 0.40f
                2 -> 0.20f
                3 -> 0.45f
                else -> 0.60f
            }
            AudioPreset.HEADSET -> when (band) {
                0 -> 0.35f
                1 -> 0.25f
                2 -> 0.30f
                3 -> 0.50f
                else -> 0.55f
            }
            AudioPreset.OFF, AudioPreset.CUSTOM -> 0f
        }

        if (state.loudSteps && band >= (totalBands / 2)) gain += 0.35f
        if (state.strongBass && band <= 1) gain += 0.45f
        if (state.cleanBass && band == 0) gain -= 0.15f
        if (state.crystalHighs && band >= totalBands - 2) gain += 0.40f
        if (state.voiceClarity && band in 1..3) gain += 0.30f
        return gain.coerceIn(-1.0f, 1.0f)
    }
}
