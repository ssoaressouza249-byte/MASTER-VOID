package com.raylan.mastervoid.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.raylan.mastervoid.audio.AudioPreset
import com.raylan.mastervoid.audio.AudioSettingsState
import com.raylan.mastervoid.model.AddedGameItem
import com.raylan.mastervoid.model.AppLanguage
import com.raylan.mastervoid.model.HzAppRule
import com.raylan.mastervoid.model.MasterVoidState
import com.raylan.mastervoid.model.PowerProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.masterVoidDataStore by preferencesDataStore(name = "master_void_prefs")

class MasterVoidPreferences(private val context: Context) {

    private object Keys {
        val MASTER_ENABLED = booleanPreferencesKey("master_enabled")
        val POWER_PROFILE = stringPreferencesKey("power_profile")
        val THEME_INDEX = intPreferencesKey("theme_index")
        val ANIMATE_BANNER = booleanPreferencesKey("animate_banner")
        val HAPTIC_ON_TAP = booleanPreferencesKey("haptic_on_tap")
        val LANGUAGE = stringPreferencesKey("language")
        val LIGHTER_APP = booleanPreferencesKey("lighter_app")
        val FAVORITES = stringSetPreferencesKey("favorites")
        val ENABLED_FEATURES = stringSetPreferencesKey("enabled_features")
        val ADDED_GAMES_JSON = stringPreferencesKey("added_games_json")

        val GAME_RES_SCALE = stringPreferencesKey("game_res_scale")
        val GAME_TARGET_FPS = stringPreferencesKey("game_target_fps")
        val STRETCHED_SCREEN = booleanPreferencesKey("stretched_screen")
        val GRAPHIC_PATH = stringPreferencesKey("graphic_path")
        val WEAK_CHIP_HELP = booleanPreferencesKey("weak_chip_help")

        val HZ_PER_APP_RULE = stringPreferencesKey("hz_per_app_rule")
        val HZ_APP_PACKAGES = stringSetPreferencesKey("hz_app_packages")
        val LOCKED_FPS_ENABLED = booleanPreferencesKey("locked_fps_enabled")
        val LOCKED_FPS_TARGET = stringPreferencesKey("locked_fps_target")
        val LOCKED_FPS_MODE = stringPreferencesKey("locked_fps_mode")
        val UI_VULKAN = booleanPreferencesKey("ui_vulkan")
        val VIVID_COLORS = stringPreferencesKey("vivid_colors")
        val GAME_COLOR_PROFILE = stringPreferencesKey("game_color_profile")
        val DARK_VISION = stringPreferencesKey("dark_vision")
        val STRONG_CONTRAST = stringPreferencesKey("strong_contrast")

        val CURRENT_DPI = intPreferencesKey("current_dpi")
        val PROTECT_RESOLUTION = booleanPreferencesKey("protect_resolution")
        val LONG_PRESS_MS = stringPreferencesKey("long_press_ms")
        val DOUBLE_TAP_MS = stringPreferencesKey("double_tap_ms")
        val POINTER_SPEED = stringPreferencesKey("pointer_speed")
        val TOUCH_WHEN_ACTIVE = stringPreferencesKey("touch_when_active")
        val FLOATING_CROSSHAIR = booleanPreferencesKey("floating_crosshair")
        val CROSSHAIR_STYLE = intPreferencesKey("crosshair_style")

        val AUDIO_JSON = stringPreferencesKey("audio_json")
        val FORBIDDEN_BG_APPS = stringSetPreferencesKey("forbidden_bg_apps")
        val FROZEN_APPS = stringSetPreferencesKey("frozen_apps")
        val FLOATING_HUD = booleanPreferencesKey("floating_hud")
        val SENSITIVE_PAUSE = booleanPreferencesKey("sensitive_pause")
        val MASTER_PROTECTION = booleanPreferencesKey("master_protection")
    }

    fun observeState(defaultDpi: Int): Flow<MasterVoidState> =
        context.masterVoidDataStore.data.map { prefs ->
            val profile = prefs[Keys.POWER_PROFILE]?.let { name ->
                runCatching { PowerProfile.valueOf(name) }.getOrNull()
            } ?: PowerProfile.BALANCED

            val language = prefs[Keys.LANGUAGE]?.let { name ->
                runCatching { AppLanguage.valueOf(name) }.getOrNull()
            } ?: AppLanguage.PT_BR

            val hzRule = prefs[Keys.HZ_PER_APP_RULE]?.let { name ->
                runCatching { HzAppRule.valueOf(name) }.getOrNull()
            } ?: HzAppRule.ADAPTIVE

            MasterVoidState(
                masterEnabled = prefs[Keys.MASTER_ENABLED] ?: true,
                currentProfile = profile,
                selectedThemeIndex = prefs[Keys.THEME_INDEX] ?: 0,
                animateBanner = prefs[Keys.ANIMATE_BANNER] ?: true,
                hapticOnTap = prefs[Keys.HAPTIC_ON_TAP] ?: true,
                language = language,
                lighterMasterVoid = prefs[Keys.LIGHTER_APP] ?: false,
                favoriteFeatureIds = prefs[Keys.FAVORITES] ?: setOf("perf_mode", "hz_max", "touch_sensitive"),
                enabledFeatureIds = prefs[Keys.ENABLED_FEATURES] ?: setOf("auto_detect", "smart_detect", "fps_adaptive"),
                addedGames = decodeGames(prefs[Keys.ADDED_GAMES_JSON]),
                gameResolutionScale = prefs[Keys.GAME_RES_SCALE] ?: "Auto",
                gameTargetFps = prefs[Keys.GAME_TARGET_FPS] ?: "Auto",
                stretchedGameScreen = prefs[Keys.STRETCHED_SCREEN] ?: false,
                graphicPath = prefs[Keys.GRAPHIC_PATH] ?: "Auto",
                weakChipHelpActive = prefs[Keys.WEAK_CHIP_HELP] ?: false,
                hzPerAppRule = hzRule,
                hzAppPackages = prefs[Keys.HZ_APP_PACKAGES] ?: emptySet(),
                lockedFpsEnabled = prefs[Keys.LOCKED_FPS_ENABLED] ?: false,
                lockedFpsTarget = prefs[Keys.LOCKED_FPS_TARGET] ?: "120 Hz",
                lockedFpsMode = prefs[Keys.LOCKED_FPS_MODE] ?: "Travado",
                uiVulkanEnabled = prefs[Keys.UI_VULKAN] ?: false,
                vividColorsLevel = prefs[Keys.VIVID_COLORS] ?: "Desligado",
                gameColorProfile = prefs[Keys.GAME_COLOR_PROFILE] ?: "Natural",
                darkVisionLevel = prefs[Keys.DARK_VISION] ?: "Desligado",
                strongContrastLevel = prefs[Keys.STRONG_CONTRAST] ?: "Desligado",
                originalDpi = defaultDpi,
                currentDpi = prefs[Keys.CURRENT_DPI] ?: defaultDpi,
                protectResolution = prefs[Keys.PROTECT_RESOLUTION] ?: true,
                longPressMs = prefs[Keys.LONG_PRESS_MS] ?: "Padrão",
                doubleTapMs = prefs[Keys.DOUBLE_TAP_MS] ?: "Padrão",
                pointerSpeed = prefs[Keys.POINTER_SPEED] ?: "0",
                touchWhenActive = prefs[Keys.TOUCH_WHEN_ACTIVE] ?: "Só no jogo",
                floatingCrosshairEnabled = prefs[Keys.FLOATING_CROSSHAIR] ?: false,
                crosshairStyle = prefs[Keys.CROSSHAIR_STYLE] ?: 0,
                audioState = decodeAudio(prefs[Keys.AUDIO_JSON]),
                forbiddenBackgroundApps = prefs[Keys.FORBIDDEN_BG_APPS] ?: emptySet(),
                frozenApps = prefs[Keys.FROZEN_APPS] ?: emptySet(),
                floatingHudEnabled = prefs[Keys.FLOATING_HUD] ?: false,
                sensitiveAppsPauseEnabled = prefs[Keys.SENSITIVE_PAUSE] ?: true,
                masterProtectionEnabled = prefs[Keys.MASTER_PROTECTION] ?: true
            )
        }

    suspend fun saveState(state: MasterVoidState) {
        context.masterVoidDataStore.edit { prefs ->
            prefs[Keys.MASTER_ENABLED] = state.masterEnabled
            prefs[Keys.POWER_PROFILE] = state.currentProfile.name
            prefs[Keys.THEME_INDEX] = state.selectedThemeIndex
            prefs[Keys.ANIMATE_BANNER] = state.animateBanner
            prefs[Keys.HAPTIC_ON_TAP] = state.hapticOnTap
            prefs[Keys.LANGUAGE] = state.language.name
            prefs[Keys.LIGHTER_APP] = state.lighterMasterVoid
            prefs[Keys.FAVORITES] = state.favoriteFeatureIds
            prefs[Keys.ENABLED_FEATURES] = state.enabledFeatureIds
            prefs[Keys.ADDED_GAMES_JSON] = encodeGames(state.addedGames)

            prefs[Keys.GAME_RES_SCALE] = state.gameResolutionScale
            prefs[Keys.GAME_TARGET_FPS] = state.gameTargetFps
            prefs[Keys.STRETCHED_SCREEN] = state.stretchedGameScreen
            prefs[Keys.GRAPHIC_PATH] = state.graphicPath
            prefs[Keys.WEAK_CHIP_HELP] = state.weakChipHelpActive

            prefs[Keys.HZ_PER_APP_RULE] = state.hzPerAppRule.name
            prefs[Keys.HZ_APP_PACKAGES] = state.hzAppPackages
            prefs[Keys.LOCKED_FPS_ENABLED] = state.lockedFpsEnabled
            prefs[Keys.LOCKED_FPS_TARGET] = state.lockedFpsTarget
            prefs[Keys.LOCKED_FPS_MODE] = state.lockedFpsMode
            prefs[Keys.UI_VULKAN] = state.uiVulkanEnabled
            prefs[Keys.VIVID_COLORS] = state.vividColorsLevel
            prefs[Keys.GAME_COLOR_PROFILE] = state.gameColorProfile
            prefs[Keys.DARK_VISION] = state.darkVisionLevel
            prefs[Keys.STRONG_CONTRAST] = state.strongContrastLevel

            prefs[Keys.CURRENT_DPI] = state.currentDpi
            prefs[Keys.PROTECT_RESOLUTION] = state.protectResolution
            prefs[Keys.LONG_PRESS_MS] = state.longPressMs
            prefs[Keys.DOUBLE_TAP_MS] = state.doubleTapMs
            prefs[Keys.POINTER_SPEED] = state.pointerSpeed
            prefs[Keys.TOUCH_WHEN_ACTIVE] = state.touchWhenActive
            prefs[Keys.FLOATING_CROSSHAIR] = state.floatingCrosshairEnabled
            prefs[Keys.CROSSHAIR_STYLE] = state.crosshairStyle

            prefs[Keys.AUDIO_JSON] = encodeAudio(state.audioState)
            prefs[Keys.FORBIDDEN_BG_APPS] = state.forbiddenBackgroundApps
            prefs[Keys.FROZEN_APPS] = state.frozenApps
            prefs[Keys.FLOATING_HUD] = state.floatingHudEnabled
            prefs[Keys.SENSITIVE_PAUSE] = state.sensitiveAppsPauseEnabled
            prefs[Keys.MASTER_PROTECTION] = state.masterProtectionEnabled
        }
    }

    private fun encodeGames(games: List<AddedGameItem>): String {
        val arr = JSONArray()
        games.forEach { g ->
            arr.put(JSONObject().apply {
                put("pkg", g.packageName)
                put("name", g.name)
                put("min", g.playTimeMinutes)
                put("fov", g.stretchedFov)
            })
        }
        return arr.toString()
    }

    private fun decodeGames(json: String?): List<AddedGameItem> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            List(arr.length()) { i ->
                val obj = arr.getJSONObject(i)
                AddedGameItem(
                    packageName = obj.getString("pkg"),
                    name = obj.getString("name"),
                    playTimeMinutes = obj.optInt("min", 0),
                    stretchedFov = obj.optBoolean("fov", false)
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun encodeAudio(audio: AudioSettingsState): String {
        return JSONObject().apply {
            put("preset", audio.preset.name)
            put("loudSteps", audio.loudSteps)
            put("strongBass", audio.strongBass)
            put("crystalHighs", audio.crystalHighs)
            put("voiceClarity", audio.voiceClarity)
            put("extraVolume6Db", audio.extraVolume6Db)
            put("compressor", audio.compressor)
            put("spatial3dHeadset", audio.spatial3dHeadset)
            put("cleanBass", audio.cleanBass)
            put("autoVol", audio.autoVolumePercent ?: -1)
            put("muteSys", audio.muteSystemSounds)
            put("exclusivity", audio.audioExclusivity)
            put("btLowLatency", audio.bluetoothLowLatency)
        }.toString()
    }

    private fun decodeAudio(json: String?): AudioSettingsState {
        if (json.isNullOrBlank()) return AudioSettingsState()
        return runCatching {
            val obj = JSONObject(json)
            val presetName = obj.optString("preset", AudioPreset.OFF.name)
            val preset = runCatching { AudioPreset.valueOf(presetName) }.getOrDefault(AudioPreset.OFF)
            val autoVol = obj.optInt("autoVol", -1).takeIf { it > 0 }
            AudioSettingsState(
                preset = preset,
                loudSteps = obj.optBoolean("loudSteps", false),
                strongBass = obj.optBoolean("strongBass", false),
                crystalHighs = obj.optBoolean("crystalHighs", false),
                voiceClarity = obj.optBoolean("voiceClarity", false),
                extraVolume6Db = obj.optBoolean("extraVolume6Db", false),
                compressor = obj.optBoolean("compressor", false),
                spatial3dHeadset = obj.optBoolean("spatial3dHeadset", false),
                cleanBass = obj.optBoolean("cleanBass", false),
                autoVolumePercent = autoVol,
                muteSystemSounds = obj.optBoolean("muteSys", false),
                audioExclusivity = obj.optBoolean("exclusivity", false),
                bluetoothLowLatency = obj.optBoolean("btLowLatency", false)
            )
        }.getOrDefault(AudioSettingsState())
    }
}
