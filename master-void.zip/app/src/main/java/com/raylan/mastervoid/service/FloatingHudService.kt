package com.raylan.mastervoid.service

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.IBinder
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.raylan.mastervoid.MainActivity
import com.raylan.mastervoid.R
import kotlin.math.roundToInt

class FloatingHudService : Service() {

    private var windowManager: WindowManager? = null
    private var hudView: TextView? = null
    private var crosshairView: CrosshairOverlayView? = null
    private var hudParams: WindowManager.LayoutParams? = null

    private var showHud = false
    private var showCrosshair = false
    private var crosshairStyle = 0
    private var accentColorInt = 0xFF8B5CF6.toInt()

    private var frameCount = 0
    private var lastFpsTimestampNs = 0L
    private var currentFps = 60

    private val choreographerCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!showHud) return
            if (lastFpsTimestampNs == 0L) {
                lastFpsTimestampNs = frameTimeNanos
            }
            frameCount++
            val elapsedNs = frameTimeNanos - lastFpsTimestampNs
            if (elapsedNs >= 1_000_000_000L) {
                currentFps = ((frameCount * 1_000_000_000.0) / elapsedNs).roundToInt()
                frameCount = 0
                lastFpsTimestampNs = frameTimeNanos
                updateHudText()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        showHud = intent?.getBooleanExtra(EXTRA_SHOW_HUD, showHud) ?: showHud
        showCrosshair = intent?.getBooleanExtra(EXTRA_SHOW_CROSSHAIR, showCrosshair) ?: showCrosshair
        crosshairStyle = intent?.getIntExtra(EXTRA_CROSSHAIR_STYLE, crosshairStyle) ?: crosshairStyle
        accentColorInt = intent?.getIntExtra(EXTRA_ACCENT_COLOR, accentColorInt) ?: accentColorInt

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!showHud && !showCrosshair) {
            stopSelf()
            return START_NOT_STICKY
        }

        syncHudOverlay()
        syncCrosshairOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(choreographerCallback)
        removeHudView()
        removeCrosshairView()
        super.onDestroy()
    }

    private fun syncHudOverlay() {
        if (showHud) {
            if (hudView == null) {
                val tv = TextView(this).apply {
                    textSize = 11.5f
                    setTextColor(Color.WHITE)
                    typeface = Typeface.MONOSPACE
                    setPadding(24, 14, 24, 14)
                    background = GradientDrawable().apply {
                        setColor(0xD914141E.toInt())
                        cornerRadius = 24f
                        setStroke(2, accentColorInt)
                    }
                }
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = 32
                    y = 140
                }
                var initialX = 0
                var initialY = 0
                var initialTouchX = 0f
                var initialTouchY = 0f
                tv.setOnTouchListener { _, event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialX = params.x
                            initialY = params.y
                            initialTouchX = event.rawX
                            initialTouchY = event.rawY
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            params.x = initialX + (event.rawX - initialTouchX).toInt()
                            params.y = initialY + (event.rawY - initialTouchY).toInt()
                            runCatching { windowManager?.updateViewLayout(tv, params) }
                            true
                        }
                        else -> false
                    }
                }
                hudParams = params
                hudView = tv
                runCatching { windowManager?.addView(tv, params) }
                lastFpsTimestampNs = 0L
                frameCount = 0
                Choreographer.getInstance().postFrameCallback(choreographerCallback)
            }
            updateHudText()
        } else {
            Choreographer.getInstance().removeFrameCallback(choreographerCallback)
            removeHudView()
        }
    }

    private fun syncCrosshairOverlay() {
        if (showCrosshair) {
            if (crosshairView == null) {
                val view = CrosshairOverlayView(this).apply {
                    styleIndex = crosshairStyle
                    colorInt = accentColorInt
                }
                val params = WindowManager.LayoutParams(
                    120,
                    120,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.CENTER
                }
                crosshairView = view
                runCatching { windowManager?.addView(view, params) }
            } else {
                crosshairView?.apply {
                    styleIndex = crosshairStyle
                    colorInt = accentColorInt
                    invalidate()
                }
            }
        } else {
            removeCrosshairView()
        }
    }

    private fun updateHudText() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val freeMb = memInfo.availMem / (1024L * 1024L)
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempC = (batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300) / 10f
        hudView?.text = "VOID HUD • ${currentFps} FPS\nRAM: ${freeMb}MB | BAT: ${tempC}°C"
    }

    private fun removeHudView() {
        hudView?.let { runCatching { windowManager?.removeView(it) } }
        hudView = null
        hudParams = null
    }

    private fun removeCrosshairView() {
        crosshairView?.let { runCatching { windowManager?.removeView(it) } }
        crosshairView = null
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.hud_service_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.hud_service_channel_desc)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingHudService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Master Void HUD Ativo")
            .setContentText("Medidor de clock e mira flutuante em execução")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Desativar", stopIntent)
            .build()
    }

    private class CrosshairOverlayView(context: Context) : View(context) {
        var styleIndex: Int = 0
        var colorInt: Int = 0xFF00E5FF.toInt()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            paint.color = colorInt
            when (styleIndex) {
                0 -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 5f, paint)
                    paint.style = Paint.Style.STROKE
                    canvas.drawCircle(cx, cy, 18f, paint)
                }
                1 -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawLine(cx - 20f, cy, cx - 6f, cy, paint)
                    canvas.drawLine(cx + 6f, cy, cx + 20f, cy, paint)
                    canvas.drawLine(cx, cy - 20f, cx, cy - 6f, paint)
                    canvas.drawLine(cx, cy + 6f, cx, cy + 20f, paint)
                }
                else -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, 6f, paint)
                }
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "master_void_hud"
        const val NOTIFICATION_ID = 7001
        const val ACTION_STOP = "com.raylan.mastervoid.STOP_HUD"
        const val EXTRA_SHOW_HUD = "extra_show_hud"
        const val EXTRA_SHOW_CROSSHAIR = "extra_show_crosshair"
        const val EXTRA_CROSSHAIR_STYLE = "extra_crosshair_style"
        const val EXTRA_ACCENT_COLOR = "extra_accent_color"

        fun updateOverlay(
            context: Context,
            showHud: Boolean,
            showCrosshair: Boolean,
            crosshairStyle: Int,
            accentColorInt: Int
        ) {
            if (!showHud && !showCrosshair) {
                context.stopService(Intent(context, FloatingHudService::class.java))
                return
            }
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, FloatingHudService::class.java).apply {
                putExtra(EXTRA_SHOW_HUD, showHud)
                putExtra(EXTRA_SHOW_CROSSHAIR, showCrosshair)
                putExtra(EXTRA_CROSSHAIR_STYLE, crosshairStyle)
                putExtra(EXTRA_ACCENT_COLOR, accentColorInt)
            }
            context.startForegroundService(intent)
        }
    }
}
