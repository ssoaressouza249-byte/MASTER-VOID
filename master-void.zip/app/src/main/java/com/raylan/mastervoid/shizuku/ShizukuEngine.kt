package com.raylan.mastervoid.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import com.raylan.mastervoid.BuildConfig
import com.raylan.mastervoid.IShellService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

enum class ShizukuStatus(val label: String) {
    NOT_INSTALLED("Não instalado"),
    DISCONNECTED("Desconectado"),
    PERMISSION_REQUIRED("Permissão pendente"),
    READY("Pronto")
}

data class CommandExecutionResult(
    val success: Boolean,
    val output: String,
    val usedShizuku: Boolean,
    val command: String
)

data class UndoActionRecord(
    val id: String,
    val title: String,
    val applyCommand: String,
    val undoCommand: String,
    val timestampMs: Long = System.currentTimeMillis()
)

class ShizukuEngine(private val context: Context) {

    private val _status = MutableStateFlow(ShizukuStatus.DISCONNECTED)
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _activeUndoStack = MutableStateFlow<List<UndoActionRecord>>(emptyList())
    val activeUndoStack: StateFlow<List<UndoActionRecord>> = _activeUndoStack.asStateFlow()

    private var shellService: IShellService? = null
    private var isBinding = false

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(BuildConfig.APPLICATION_ID, ShellUserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            shellService = IShellService.Stub.asInterface(service)
            isBinding = false
            refreshStatus()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shellService = null
            isBinding = false
            refreshStatus()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        shellService = null
        isBinding = false
        refreshStatus()
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            bindShellServiceIfReady()
        }
        refreshStatus()
    }

    fun initialize() {
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        }
        refreshStatus()
    }

    fun release() {
        runCatching {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            if (shellService != null) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
            }
        }
    }

    fun refreshStatus() {
        val shizukuInstalled = isPackageInstalled("moe.shizuku.privileged.api")
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

        if (!binderAlive) {
            _status.value = if (shizukuInstalled) ShizukuStatus.DISCONNECTED else ShizukuStatus.NOT_INSTALLED
            return
        }

        val granted = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

        if (!granted) {
            _status.value = ShizukuStatus.PERMISSION_REQUIRED
            return
        }

        bindShellServiceIfReady()
        _status.value = ShizukuStatus.READY
    }

    fun requestPermissionOrOpenShizuku() {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (binderAlive) {
            val granted = runCatching {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(false)
            if (!granted) {
                runCatching { Shizuku.requestPermission(SHIZUKU_REQ_CODE) }
            } else {
                bindShellServiceIfReady()
            }
        } else {
            val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(launchIntent) }
            }
        }
        refreshStatus()
    }

    private fun bindShellServiceIfReady() {
        if (shellService != null || isBinding) return
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        if (binderAlive && granted) {
            isBinding = true
            runCatching {
                Shizuku.bindUserService(userServiceArgs, serviceConnection)
            }.onFailure {
                isBinding = false
            }
        }
    }

    suspend fun runCommand(
        command: String,
        timeoutSeconds: Int = 10
    ): CommandExecutionResult = withContext(Dispatchers.IO) {
        if (command.isBlank()) {
            return@withContext CommandExecutionResult(false, "Comando vazio", false, command)
        }

        val service = shellService
        if (service != null) {
            val output = runCatching { service.exec(command, timeoutSeconds) }.getOrElse {
                "[ERRO BINDER] ${it.message}"
            }
            val ok = !output.startsWith("[ERRO") && !output.startsWith("[EXIT") && !output.contains("[TIMEOUT")
            return@withContext CommandExecutionResult(ok, output, true, command)
        }

        // Local unprivileged fallback for read-only commands like getprop / cat /proc/*
        if (isSafeLocalReadCommand(command)) {
            val localOut = runLocalReadCommand(command)
            return@withContext CommandExecutionResult(true, localOut, false, command)
        }

        CommandExecutionResult(
            success = false,
            output = "Shizuku desconectado — comando preparado: $command",
            usedShizuku = false,
            command = command
        )
    }

    suspend fun executeWithUndo(
        id: String,
        title: String,
        applyCommand: String,
        undoCommand: String,
        timeoutSeconds: Int = 10
    ): CommandExecutionResult {
        val result = runCommand(applyCommand, timeoutSeconds)
        if (undoCommand.isNotBlank()) {
            val current = _activeUndoStack.value.filterNot { it.id == id }
            _activeUndoStack.value = current + UndoActionRecord(
                id = id,
                title = title,
                applyCommand = applyCommand,
                undoCommand = undoCommand
            )
        }
        return result
    }

    suspend fun undoAction(id: String): CommandExecutionResult? {
        val record = _activeUndoStack.value.find { it.id == id } ?: return null
        val res = runCommand(record.undoCommand, timeoutSeconds = 10)
        _activeUndoStack.value = _activeUndoStack.value.filterNot { it.id == id }
        return res
    }

    suspend fun undoAll(): List<CommandExecutionResult> {
        val records = _activeUndoStack.value.reversed()
        val results = mutableListOf<CommandExecutionResult>()
        for (record in records) {
            results += runCommand(record.undoCommand, timeoutSeconds = 10)
        }
        _activeUndoStack.value = emptyList()
        return results
    }

    private fun isSafeLocalReadCommand(cmd: String): Boolean {
        val trimmed = cmd.trim()
        return trimmed.startsWith("getprop") ||
            trimmed.startsWith("cat /proc/") ||
            trimmed.startsWith("uname") ||
            trimmed.startsWith("wm size") ||
            trimmed.startsWith("wm density")
    }

    private fun runLocalReadCommand(cmd: String): String {
        return runCatching {
            val process = ProcessBuilder("sh", "-c", cmd)
                .redirectErrorStream(true)
                .start()
            val text = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            process.waitFor()
            text.ifEmpty { "Sem saída" }
        }.getOrElse { it.message ?: "Erro local" }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    packageName,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
        }.isSuccess
    }

    companion object {
        private const val SHIZUKU_REQ_CODE = 1001
    }
}
