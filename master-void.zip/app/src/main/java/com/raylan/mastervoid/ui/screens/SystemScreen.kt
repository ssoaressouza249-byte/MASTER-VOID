package com.raylan.mastervoid.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.mastervoid.model.AppLanguage
import com.raylan.mastervoid.model.MasterVoidCatalog
import com.raylan.mastervoid.model.MasterVoidState
import com.raylan.mastervoid.telemetry.HardwareTelemetry
import com.raylan.mastervoid.telemetry.InstalledAppItem
import com.raylan.mastervoid.ui.components.AppIconImage
import com.raylan.mastervoid.ui.components.AppPickerDialog
import com.raylan.mastervoid.ui.components.MasterVoidFooter
import com.raylan.mastervoid.ui.components.VoidCardContainer
import com.raylan.mastervoid.ui.components.VoidFeatureToggleRow
import com.raylan.mastervoid.ui.components.VoidOptionChipRow
import com.raylan.mastervoid.ui.components.VoidSectionHeader
import com.raylan.mastervoid.ui.theme.MasterVoidThemes
import com.raylan.mastervoid.ui.theme.VoidBorder
import com.raylan.mastervoid.ui.theme.VoidCard
import com.raylan.mastervoid.ui.theme.VoidCardElevated
import com.raylan.mastervoid.ui.theme.VoidGreen
import com.raylan.mastervoid.ui.theme.VoidRed
import com.raylan.mastervoid.ui.theme.VoidTextMuted
import com.raylan.mastervoid.ui.theme.VoidTextPrimary
import com.raylan.mastervoid.ui.theme.VoidTextSecondary
import com.raylan.mastervoid.viewmodel.MasterVoidViewModel

@Composable
fun SystemScreen(
    state: MasterVoidState,
    telemetry: HardwareTelemetry,
    installedApps: List<InstalledAppItem>,
    viewModel: MasterVoidViewModel
) {
    val context = LocalContext.current
    var showForbiddenPicker by remember { mutableStateOf(false) }
    var showFreezePicker by remember { mutableStateOf(false) }
    var showSettingsEditor by remember { mutableStateOf(false) }
    var infoModalTitle by remember { mutableStateOf<String?>(null) }
    var infoModalBody by remember { mutableStateOf("") }

    val duringGameIds = listOf(
        "sys_pause_backup", "sys_block_alarms", "sys_pause_compile",
        "sys_block_wakeup", "sys_pause_store", "sys_pause_a11y",
        "sys_pause_intelligence", "sys_whatsapp_no_dl", "sys_pause_quickshare"
    )
    val bgAlwaysIds = listOf(
        "sys_night_opt", "sys_fast_storage", "sys_clear_cache",
        "sys_lighter", "sys_forbidden_bg", "sys_no_oem_autostart", "sys_no_preload"
    )
    val silentAndroidIds = listOf(
        "sys_no_crash_reports", "sys_clean_telemetry", "sys_clear_logs",
        "sys_app_analyzer", "sys_always_opt_apps", "sys_post_update_turbo",
        "sys_idle_sleep", "sys_forgotten_hibernate", "sys_compile_system",
        "sys_fast_doze", "sys_eco_location", "sys_batch_jobs", "sys_clean_giant_cache"
    )
    val googleIds = listOf(
        "gms_turbo", "gms_modules", "gms_lean", "gms_gboard",
        "gms_playstore", "gms_google_app", "gms_chrome", "gms_youtube",
        "gms_ai_compiled", "gms_always_opt", "gms_play_games"
    )
    val webViewIds = listOf("wv_compiled", "wv_newest", "wv_single", "wv_always_compiled")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            VoidSectionHeader(
                title = "1. Durante o jogo",
                subtitle = "Bloqueios temporários enquanto você joga"
            )
        }
        items(duringGameIds.size) { idx ->
            SysFeatureRow(duringGameIds[idx], state, viewModel)
        }

        item {
            Spacer(Modifier.height(6.dp))
            VoidSectionHeader(
                title = "2. Sempre ativo & Segundo plano",
                subtitle = "Manutenção de armazenamento, RAM e processos ocultos"
            )
        }
        items(bgAlwaysIds.size) { idx ->
            SysFeatureRow(bgAlwaysIds[idx], state, viewModel)
        }

        item {
            VoidCardContainer(highlighted = state.forbiddenBackgroundApps.isNotEmpty()) {
                VoidSectionHeader(
                    title = "Apps proibidos em segundo plano",
                    badge = "${state.forbiddenBackgroundApps.size} apps"
                )
                Spacer(Modifier.height(8.dp))
                if (state.forbiddenBackgroundApps.isEmpty()) {
                    Text(
                        text = "Nenhum app restrito ainda. Escolha apps pesados para impedir execução em segundo plano.",
                        style = MaterialTheme.typography.bodySmall,
                        color = VoidTextSecondary
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        state.forbiddenBackgroundApps.forEach { pkg ->
                            val icon = remember(pkg) { viewModel.loadAppIcon(pkg) }
                            val label = remember(pkg, installedApps) {
                                installedApps.find { it.packageName == pkg }?.label ?: pkg.substringAfterLast(".")
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(64.dp)
                            ) {
                                AppIconImage(
                                    drawable = icon,
                                    contentDescription = label,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VoidTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            viewModel.refreshInstalledApps(false)
                            showForbiddenPicker = true
                        },
                        modifier = Modifier.weight(1f).testTag("choose_forbidden_bg"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("+ Escolher")
                    }
                    OutlinedButton(
                        onClick = { viewModel.releaseAllForbiddenBgApps() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Liberar todos")
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            VoidSectionHeader(
                title = "3. Sistema silencioso & Android leve",
                subtitle = "Compilação ART, Doze rápido e eliminação de telemetria"
            )
        }
        items(silentAndroidIds.size) { idx ->
            SysFeatureRow(silentAndroidIds[idx], state, viewModel)
        }

        item {
            Spacer(Modifier.height(6.dp))
            VoidSectionHeader(
                title = "4. Serviços Google & WebView",
                subtitle = "Compilação AOT para Play Services, Play Store e WebView"
            )
        }
        items(googleIds.size) { idx ->
            SysFeatureRow(googleIds[idx], state, viewModel)
        }

        item {
            VoidSectionHeader(
                title = "WebView",
                subtitle = "Motor de renderização web do sistema"
            )
        }
        items(webViewIds.size) { idx ->
            SysFeatureRow(webViewIds[idx], state, viewModel)
        }

        item {
            Spacer(Modifier.height(6.dp))
            VoidSectionHeader(
                title = "5. Medidores, Registros, Proteção & Aparência",
                subtitle = "Diagnóstico, Editor, HUD, 10 Cores e Créditos"
            )
        }

        item {
            VoidCardContainer {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SystemToolButton(
                            icon = Icons.Filled.HealthAndSafety,
                            title = "Diagnóstico: por que está lento?",
                            onClick = {
                                infoModalTitle = "Diagnóstico do Aparelho"
                                infoModalBody = viewModel.runDiagnosticSlowness()
                            },
                            modifier = Modifier.weight(1f)
                        )
                        SystemToolButton(
                            icon = Icons.Filled.Build,
                            title = "Reparar restrições",
                            onClick = {
                                viewModel.executeRepairRestrictions { out ->
                                    infoModalTitle = "Reparar Restrições"
                                    infoModalBody = "Resultado:\n$out"
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SystemToolButton(
                            icon = Icons.Filled.Shield,
                            title = "Congelar apps (${state.frozenApps.size})",
                            onClick = {
                                viewModel.refreshInstalledApps(false)
                                showFreezePicker = true
                            },
                            modifier = Modifier.weight(1f)
                        )
                        SystemToolButton(
                            icon = Icons.Filled.Code,
                            title = "Editor de Configurações",
                            onClick = { showSettingsEditor = true },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SystemToolButton(
                            icon = Icons.Filled.Speed,
                            title = "Prioridade Máxima",
                            onClick = {
                                infoModalTitle = "Prioridade Máxima"
                                infoModalBody = "Prioridade de CPU, I/O e memória aplicada ao processo do jogo em primeiro plano via GameManager / cgroup."
                            },
                            modifier = Modifier.weight(1f)
                        )
                        SystemToolButton(
                            icon = Icons.Filled.Info,
                            title = "Relatório da partida",
                            onClick = {
                                infoModalTitle = "Relatório da Partida"
                                infoModalBody = "Perfil ativo: ${state.currentProfile.label}\nTemperatura atual: ${telemetry.batteryTempC}°C (${telemetry.tempBadge.label})\nRAM livre: ${telemetry.ramFreeMb} MB\nTaxa atual: ${telemetry.currentRefreshHz} Hz\nFunções ativas: ${viewModel.activeFeatureCount()}"
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SystemToolButton(
                            icon = Icons.Filled.Check,
                            title = "Prova por função",
                            onClick = {
                                val enabled = MasterVoidCatalog.allFeatures.filter { it.id in state.enabledFeatureIds }
                                infoModalTitle = "Prova por Função (${enabled.size} ativas)"
                                infoModalBody = if (enabled.isEmpty()) {
                                    "Nenhuma função ativa no momento."
                                } else {
                                    enabled.joinToString("\n\n") { "• ${it.title}\n  Cmd: ${it.applyCmd.ifBlank { "Motor interno / JVM" }}" }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        SystemToolButton(
                            icon = Icons.Filled.Science,
                            title = "Dna Master & Labs",
                            onClick = {
                                infoModalTitle = "DNA Master & Labs"
                                infoModalBody = "SoC: ${telemetry.chipSoc}\nGPU: ${telemetry.gpuName}\nResolução: ${telemetry.screenResolution} (${telemetry.densityDpi} DPI)\nTaxas suportadas: ${telemetry.supportedRefreshHz.joinToString(" / ") { "${it}Hz" }}\n\nLabs experimental: Pipeline SkiaVulkan + AOT Speed-Profile."
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SystemToolButton(
                            icon = Icons.Filled.History,
                            title = "Registro de atividades (${state.activityLogs.size})",
                            onClick = {
                                infoModalTitle = "Registro de Atividades"
                                infoModalBody = if (state.activityLogs.isEmpty()) {
                                    "Nenhuma atividade registrada nesta sessão."
                                } else {
                                    state.activityLogs.take(15).joinToString("\n\n") { log ->
                                        "[${log.timeLabel}] ${log.title}\n${log.detail}"
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        SystemToolButton(
                            icon = Icons.Filled.Info,
                            title = "Relatório do aparelho",
                            onClick = {
                                infoModalTitle = "Relatório do Aparelho"
                                infoModalBody = "Modelo: ${telemetry.deviceModel}\nSoC: ${telemetry.chipSoc}\nGPU: ${telemetry.gpuName}\n${telemetry.androidVersionLabel}\nRAM: ${telemetry.ramFreeMb} / ${telemetry.ramTotalMb} MB\nBateria: ${telemetry.batteryPercent}% (${telemetry.batteryTempC}°C)"
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            VoidCardContainer(highlighted = state.floatingHudEnabled) {
                VoidFeatureToggleRow(
                    featureId = "hud_clock",
                    title = "Medidor de clock (HUD Flutuante FPS/CPU/GPU)",
                    subtitle = "Exibe janela flutuante arrastável com FPS e térmica ao vivo",
                    checked = state.floatingHudEnabled,
                    onCheckedChange = {
                        if (!Settings.canDrawOverlays(context)) {
                            context.startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } else {
                            viewModel.toggleFloatingHud()
                        }
                    }
                )
                Spacer(Modifier.height(8.dp))
                VoidFeatureToggleRow(
                    featureId = "sensitive_pause",
                    title = "Pausa em apps sensíveis",
                    subtitle = "Pausa ajustes agressivos automaticamente em bancos e câmera",
                    checked = state.sensitiveAppsPauseEnabled,
                    onCheckedChange = { viewModel.toggleSensitiveAppsPause() }
                )
                Spacer(Modifier.height(8.dp))
                VoidFeatureToggleRow(
                    featureId = "master_protection",
                    title = "Proteção Master (Escudo anti-crash & resgate)",
                    subtitle = "Mantém fallback seguro de resolução, DPI e animações",
                    checked = state.masterProtectionEnabled,
                    onCheckedChange = { viewModel.toggleMasterProtection() }
                )
                Spacer(Modifier.height(8.dp))
                VoidFeatureToggleRow(
                    featureId = "lighter_master_void",
                    title = "Master Void mais leve",
                    subtitle = "Reduz consumo de memória da própria interface",
                    checked = state.lighterMasterVoid,
                    onCheckedChange = { viewModel.toggleLighterMasterVoid() }
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.undoAllActiveFunctions() },
                    modifier = Modifier.fillMaxWidth().testTag("undo_all_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VoidRed.copy(alpha = 0.2f),
                        contentColor = Color(0xFFFCA5A5)
                    ),
                    border = BorderStroke(1.dp, VoidRed.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Undo, contentDescription = "Desfazer tudo", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Funções ativas (${viewModel.activeFeatureCount()}) • Desfazer tudo num toque")
                }
            }
        }

        // Aparência & 10 Cores
        item {
            VoidCardContainer {
                VoidSectionHeader(
                    title = "Aparência & 10 Cores do App",
                    badge = MasterVoidThemes[state.selectedThemeIndex].name
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MasterVoidThemes.forEachIndexed { index, palette ->
                        val selected = index == state.selectedThemeIndex
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable { viewModel.selectTheme(index) }
                                .testTag("theme_swatch_$index")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(palette.primary)
                                    .border(
                                        width = if (selected) 3.dp else 1.dp,
                                        color = if (selected) Color.White else VoidBorder,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = palette.name,
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) palette.primary else VoidTextMuted
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                VoidFeatureToggleRow(
                    featureId = "sys_banner_anim",
                    title = "Banner animado",
                    subtitle = "Efeito de respiração suave no banner do Robô e Sol",
                    checked = state.animateBanner,
                    onCheckedChange = { viewModel.toggleAnimateBanner() }
                )
                Spacer(Modifier.height(8.dp))
                VoidFeatureToggleRow(
                    featureId = "sys_haptic",
                    title = "Vibração ao tocar",
                    subtitle = "Feedback tátil sutil ao alternar switches",
                    checked = state.hapticOnTap,
                    onCheckedChange = { viewModel.toggleHapticOnTap() }
                )
                Spacer(Modifier.height(10.dp))
                VoidOptionChipRow(
                    label = "Idioma",
                    options = AppLanguage.entries.map { it.label },
                    selectedOption = state.language.label,
                    onSelect = { label ->
                        AppLanguage.entries.find { it.label == label }?.let { viewModel.setLanguage(it) }
                    }
                )
            }
        }

        // Sobre o criador: Raylan
        item {
            VoidCardContainer(highlighted = true) {
                VoidSectionHeader(
                    title = "Sobre o criador",
                    badge = "OFICIAL"
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Master Void 1.0 • Desenvolvido por Raylan",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Suíte nativa de otimização gamer sem root construída com Jetpack Compose, Material 3, AudioFX DSP e Shizuku AIDL Shell.",
                    style = MaterialTheme.typography.bodySmall,
                    color = VoidTextSecondary
                )
            }
        }

        item {
            MasterVoidFooter()
        }
    }

    if (showForbiddenPicker) {
        AppPickerDialog(
            title = "Proibir app em segundo plano",
            apps = installedApps,
            loadIcon = viewModel::loadAppIcon,
            onSelect = { app ->
                viewModel.addForbiddenBgApp(app.packageName)
                showForbiddenPicker = false
            },
            onDismiss = { showForbiddenPicker = false }
        )
    }

    if (showFreezePicker) {
        AppPickerDialog(
            title = "Congelar / Descongelar app",
            apps = installedApps,
            loadIcon = viewModel::loadAppIcon,
            onSelect = { app ->
                viewModel.toggleFreezeApp(app.packageName)
                showFreezePicker = false
            },
            onDismiss = { showFreezePicker = false }
        )
    }

    if (showSettingsEditor) {
        SettingsEditorDialog(
            onExecute = { ns, key, value, cb -> viewModel.executeSettingsEditor(ns, key, value, cb) },
            onDismiss = { showSettingsEditor = false }
        )
    }

    if (infoModalTitle != null) {
        AlertDialog(
            onDismissRequest = { infoModalTitle = null },
            containerColor = VoidCard,
            title = { Text(infoModalTitle ?: "", color = VoidTextPrimary) },
            text = {
                Column(modifier = Modifier.heightIn(max = 360.dp)) {
                    Text(
                        text = infoModalBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = VoidTextSecondary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { infoModalTitle = null }) {
                    Text("Fechar", color = MaterialTheme.colorScheme.secondary)
                }
            }
        )
    }
}

@Composable
private fun SysFeatureRow(
    featureId: String,
    state: MasterVoidState,
    viewModel: MasterVoidViewModel
) {
    val meta = remember(featureId) { MasterVoidCatalog.allFeatures.find { it.id == featureId } } ?: return
    VoidFeatureToggleRow(
        featureId = meta.id,
        title = meta.title,
        subtitle = meta.subtitle,
        checked = meta.id in state.enabledFeatureIds,
        onCheckedChange = { viewModel.toggleFeature(meta.id) },
        isFavorite = meta.id in state.favoriteFeatureIds,
        onFavoriteToggle = { viewModel.toggleFavorite(meta.id) },
        hapticEnabled = state.hapticOnTap
    )
}

@Composable
private fun SystemToolButton(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        color = VoidCardElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, VoidBorder)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = VoidTextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SettingsEditorDialog(
    onExecute: (namespace: String, key: String, value: String?, onResult: (String) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var namespace by remember { mutableStateOf("system") }
    var key by remember { mutableStateOf("pointer_speed") }
    var value by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Pronto para ler ou gravar via Shizuku.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VoidCard,
        title = { Text("Editor de Configurações", color = VoidTextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                VoidOptionChipRow(
                    label = "Tabela",
                    options = listOf("system", "secure", "global", "props"),
                    selectedOption = namespace,
                    onSelect = { namespace = it }
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("Chave (Key)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Valor (vazio para apenas ler)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = output,
                    style = MaterialTheme.typography.labelSmall,
                    color = VoidGreen
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onExecute(namespace, key.trim(), value.trim().ifBlank { null }) { res ->
                    output = "Retorno: $res"
                }
            }) {
                Text(if (value.isBlank()) "Ler" else "Aplicar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar", color = VoidTextSecondary)
            }
        }
    )
}
