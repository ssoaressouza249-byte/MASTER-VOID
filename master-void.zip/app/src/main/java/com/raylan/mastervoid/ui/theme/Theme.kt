package com.raylan.mastervoid.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val MasterVoidShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun MasterVoidTheme(
    themeIndex: Int = 0,
    content: @Composable () -> Unit
) {
    val palette = MasterVoidThemes.getOrElse(themeIndex) { MasterVoidThemes[0] }
    val colorScheme = darkColorScheme(
        primary = palette.primary,
        onPrimary = Color(0xFF0B0B10),
        primaryContainer = palette.primary.copy(alpha = 0.18f),
        onPrimaryContainer = palette.primary,
        secondary = palette.secondary,
        onSecondary = Color(0xFF0B0B10),
        secondaryContainer = palette.secondary.copy(alpha = 0.16f),
        onSecondaryContainer = palette.secondary,
        tertiary = VoidGreen,
        background = VoidBackground,
        onBackground = VoidTextPrimary,
        surface = VoidSurface,
        onSurface = VoidTextPrimary,
        surfaceVariant = VoidCard,
        onSurfaceVariant = VoidTextSecondary,
        outline = VoidBorder,
        error = VoidRed,
        onError = Color.White
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MasterVoidTypography,
        shapes = MasterVoidShapes,
        content = content
    )
}
