package com.raylan.mastervoid.model

import com.raylan.mastervoid.audio.AudioSettingsState

enum class PowerProfile(
    val label: String,
    val description: String,
    val fpsBar: Float,
    val batteryBar: Float,
    val coolBar: Float
) {
    BATTERY("Bateria", "Autonomia máxima e menor calor", 0.56f, 0.96f, 0.94f),
    BALANCED("Equilíbrio", "Estabilidade contínua e térmicas seguras", 0.80f, 0.76f, 0.78f),
    MAXIMUM("Máximo", "Desempenho extremo e resposta imediata", 1.00f, 0.44f, 0.52f)
}

enum class MainTab(val label: String) {
    HOME("Início"),
    GAME("Jogo"),
    SYSTEM("Sistema"),
    MODULES("Módulos")
}

enum class GameSubTab(val label: String) {
    GAMES_ENGINE("Jogos e Motor"),
    PERFORMANCE("Desempenho"),
    SCREEN_IMAGE("Tela e Imagem"),
    TOUCH_AIM("Toque e Mira"),
    SOUND("Som")
}

enum class AppLanguage(val label: String) {
    PT_BR("Português (BR)"),
    EN("English"),
    ES("Español")
}

enum class HzAppRule(val label: String) {
    ALWAYS_MAX("Sempre no máximo"),
    ALWAYS_MIN("Sempre no mínimo"),
    ADAPTIVE("Adaptativo")
}

data class AddedGameItem(
    val packageName: String,
    val name: String,
    val playTimeMinutes: Int = 0,
    val stretchedFov: Boolean = false
)

data class FeatureMeta(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val applyCmd: String = "",
    val undoCmd: String = ""
)

data class ActivityLogEntry(
    val id: Long = System.currentTimeMillis(),
    val timeLabel: String,
    val title: String,
    val detail: String,
    val usedShizuku: Boolean,
    val success: Boolean
)

data class MasterScriptItem(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val command: String,
    val undoCommand: String,
    val timeoutSeconds: Int = 12
)

data class DpiTestState(
    val isTesting: Boolean = false,
    val targetDpi: Int = 420,
    val originalDpi: Int = 420,
    val secondsRemaining: Int = 15
)

data class MasterVoidState(
    val masterEnabled: Boolean = true,
    val currentProfile: PowerProfile = PowerProfile.BALANCED,
    val selectedThemeIndex: Int = 0,
    val animateBanner: Boolean = true,
    val hapticOnTap: Boolean = true,
    val language: AppLanguage = AppLanguage.PT_BR,
    val lighterMasterVoid: Boolean = false,
    val favoriteFeatureIds: Set<String> = setOf("perf_mode", "hz_max", "touch_sensitive", "audio_fps"),
    val enabledFeatureIds: Set<String> = setOf("auto_detect", "smart_detect", "fps_adaptive"),

    // Jogos e Motor
    val addedGames: List<AddedGameItem> = emptyList(),

    // Desempenho - Resolução, FPS, Caminho gráfico, IA Master
    val gameResolutionScale: String = "Auto",
    val gameTargetFps: String = "Auto",
    val stretchedGameScreen: Boolean = false,
    val graphicPath: String = "Auto",
    val weakChipHelpActive: Boolean = false,

    // Tela e Imagem
    val hzPerAppRule: HzAppRule = HzAppRule.ADAPTIVE,
    val hzAppPackages: Set<String> = emptySet(),
    val lockedFpsEnabled: Boolean = false,
    val lockedFpsTarget: String = "120 Hz",
    val lockedFpsMode: String = "Travado",
    val uiVulkanEnabled: Boolean = false,
    val vividColorsLevel: String = "Desligado",
    val gameColorProfile: String = "Natural",
    val darkVisionLevel: String = "Desligado",
    val strongContrastLevel: String = "Desligado",

    // Toque e Mira
    val originalDpi: Int = 420,
    val currentDpi: Int = 420,
    val protectResolution: Boolean = true,
    val dpiTestState: DpiTestState = DpiTestState(),
    val longPressMs: String = "Padrão",
    val doubleTapMs: String = "Padrão",
    val pointerSpeed: String = "0",
    val touchWhenActive: String = "Só no jogo",
    val floatingCrosshairEnabled: Boolean = false,
    val crosshairStyle: Int = 0,

    // Som
    val audioState: AudioSettingsState = AudioSettingsState(),

    // Sistema
    val forbiddenBackgroundApps: Set<String> = emptySet(),
    val frozenApps: Set<String> = emptySet(),
    val floatingHudEnabled: Boolean = false,
    val sensitiveAppsPauseEnabled: Boolean = true,
    val masterProtectionEnabled: Boolean = true,
    val activityLogs: List<ActivityLogEntry> = emptyList(),
    val lastCommandOutput: String = ""
)

object MasterVoidCatalog {

    val allFeatures: List<FeatureMeta> = listOf(
        // Sub-aba 1: Jogos e Motor
        FeatureMeta("auto_detect", "Detecção Automática", "Detecta quando um jogo entra em primeiro plano", "Motor", "", ""),
        FeatureMeta("smart_detect", "Detecção Inteligente", "Analisa carga de CPU/GPU antes de aplicar ajustes", "Motor", "", ""),
        FeatureMeta("game_only", "Só no Jogo", "Aplica perfis agressivos apenas durante partidas", "Motor", "", ""),
        FeatureMeta("app_support", "Apoio nos Apps", "Otimiza fluidez fora de jogos para interface ágil", "Motor", "", ""),
        FeatureMeta("ia_master", "IA Master", "Orquestra frequência, térmicas e memória num único cérebro", "Motor", "", ""),
        FeatureMeta("fps_adaptive", "FPS Adaptativo", "Ajusta quadros dinamicamente evitando aquecimento", "Motor", "", ""),

        // Sub-aba 2: Desempenho
        FeatureMeta(
            "perf_mode", "Modo Desempenho", "Prioriza estabilidade e clock sustentado (fixed_performance)",
            "Desempenho",
            "cmd power set-fixed-performance-mode-enabled true",
            "cmd power set-fixed-performance-mode-enabled false"
        ),
        FeatureMeta("check_game_mode", "Conferir Modo de Jogo", "Verifica integração GameManager Android (API 31+)", "Desempenho", "cmd game mode performance", "cmd game mode standard"),
        FeatureMeta("lag_detector", "Detector de Travadas", "Monitora jank e quedas de frametime em tempo real", "Desempenho", "dumpsys gfxinfo --framestats", ""),
        FeatureMeta("updated_driver", "Driver Atualizado", "Ativa driver gráfico pré-instalado / Game Driver", "Desempenho", "settings put global updatable_driver_all_apps 1", "settings put global updatable_driver_all_apps 0"),
        FeatureMeta("keep_screen_on", "Tela Acesa na Partida", "Impede suspensão automática da tela ao jogar", "Desempenho", "settings put system screen_off_timeout 1800000", "settings put system screen_off_timeout 60000"),
        FeatureMeta("soc_profile", "Perfil por Processador", "Calibra escalonamento de acordo com o SoC detectado", "Desempenho", "", ""),
        FeatureMeta("genre_profile", "Perfil por Gênero", "Ajusta resposta para FPS, MOBA ou Mundo Aberto", "Desempenho", "", ""),
        FeatureMeta("ia_learn_game", "IA • Aprendizado por jogo", "Aprende picos de calor e cena pesada por pacote", "IA Master", "", ""),
        FeatureMeta("ia_live_pilot", "IA • Piloto ao vivo antes do calor", "Reduz carga secundária antes do thermal throttling", "IA Master", "", ""),
        FeatureMeta("ia_drop_forecast", "IA • Previsão de queda", "Antecipa quedas de FPS e estabiliza renderização", "IA Master", "", ""),

        // Sub-aba 3: Tela e Imagem
        FeatureMeta("hz_max", "Hz Máximo", "Força a maior taxa de atualização suportada pelo painel", "Tela", "settings put system min_refresh_rate 120.0", "settings delete system min_refresh_rate"),
        FeatureMeta("no_blur", "Sem Desfoque", "Desativa blurs pesados de composição na GPU", "Tela", "settings put global disable_window_blurs 1", "settings put global disable_window_blurs 0"),
        FeatureMeta("light_anim", "Animações Leves (0.5x)", "Reduz escalas de animação do sistema para 0.5x", "Tela", "settings put global window_animation_scale 0.5 && settings put global transition_animation_scale 0.5 && settings put global animator_duration_scale 0.5", "settings put global window_animation_scale 1.0 && settings put global transition_animation_scale 1.0 && settings put global animator_duration_scale 1.0"),
        FeatureMeta("light_home", "Tela Inicial Leve", "Libera memória do launcher ao entrar em jogos", "Tela", "", ""),
        FeatureMeta("hz_adaptive", "Hz Adaptativo", "Alterna taxa de atualização conforme movimento na tela", "Tela", "settings put system min_refresh_rate 60.0", "settings delete system min_refresh_rate"),
        FeatureMeta("auto_hz_profile", "Perfil Automático de Tela", "Aplica brilho e taxa ideais por perfil ativo", "Tela", "", ""),
        FeatureMeta("angle_renderer", "Renderizador ANGLE", "Usa camada ANGLE Vulkan para OpenGL ES estável", "Imagem", "settings put global angle_gl_driver_all_angle 1", "settings put global angle_gl_driver_all_angle 0"),
        FeatureMeta("hd_mode", "Modo HD", "Prioriza nitidez e filtragem anisotrópica em texturas", "Imagem", "setprop debug.hwui.filter_test_overhead false", ""),
        FeatureMeta("true_colors", "Cores Reais", "Ativa calibração sRGB / ampla gama precisa", "Imagem", "service call SurfaceFlinger 1023 i32 0", ""),
        FeatureMeta("max_screen_res", "Resolução Máxima da Tela", "Restaura resolução nativa máxima do display", "Imagem", "wm size reset", ""),

        // Sub-aba 4: Toque e Mira
        FeatureMeta("free_edges", "Bordas Livres", "Reduz rejeição de toque nas bordas curvas", "Toque", "settings put secure edge_touch_prevention 0", "settings put secure edge_touch_prevention 1"),
        FeatureMeta("fixed_nav", "Navegação Fixa", "Evita toques acidentais na barra de navegação", "Toque", "", ""),
        FeatureMeta("locked_rotation", "Rotação Travada", "Trava auto-rotação durante a partida", "Toque", "settings put system accelerometer_rotation 0", "settings put system accelerometer_rotation 1"),
        FeatureMeta("no_vibration", "Sem Vibração", "Silencia feedback háptico para economizar bateria e foco", "Toque", "settings put system haptic_feedback_enabled 0", "settings put system haptic_feedback_enabled 1"),
        FeatureMeta("light_match_mode", "Modo Leve na Partida", "Reduz processos de overlay não essenciais no jogo", "Toque", "", ""),
        FeatureMeta("zero_anim", "Zero Animação", "Define animações do sistema para 0.0x (resposta instantânea)", "Toque", "settings put global window_animation_scale 0 && settings put global transition_animation_scale 0 && settings put global animator_duration_scale 0", "settings put global window_animation_scale 1 && settings put global transition_animation_scale 1 && settings put global animator_duration_scale 1"),
        FeatureMeta("pointer_speed_boost", "Velocidade do Ponteiro", "Aplica sensibilidade aprimorada ao ponteiro de toque", "Toque", "settings put system pointer_speed 5", "settings put system pointer_speed 0"),
        FeatureMeta("touch_sensitive", "Toque Sensível (Película / Luva)", "Aumenta sensibilidade da camada capacitiva", "Toque", "settings put secure touch_sensitivity_mode 1", "settings put secure touch_sensitivity_mode 0"),

        // Sistema - Seção 1: Durante o jogo
        FeatureMeta("sys_pause_backup", "Pausar Backup", "Suspende backup em nuvem durante partidas", "Durante o jogo", "bmgr enabled false", "bmgr enabled true"),
        FeatureMeta("sys_block_alarms", "Bloqueio de Alarmes", "Adia alarmes não críticos e wakeups de fundo", "Durante o jogo", "", ""),
        FeatureMeta("sys_pause_compile", "Pausar Compilação", "Pausa dexopt em segundo plano durante jogos", "Durante o jogo", "cmd package bg-dexopt-job --cancel", ""),
        FeatureMeta("sys_block_wakeup", "Bloqueio de Despertar", "Reduz wakelocks de rádio e sensores em segundo plano", "Durante o jogo", "", ""),
        FeatureMeta("sys_pause_store", "Pausar Loja", "Pausa atualizações automáticas da Play Store no jogo", "Durante o jogo", "am set-standby-bucket com.android.vending restricted", "am set-standby-bucket com.android.vending active"),
        FeatureMeta("sys_pause_a11y", "Acessibilidade Pausada no Jogo", "Reduz sobrecarga de serviços de acessibilidade ao jogar", "Durante o jogo", "", ""),
        FeatureMeta("sys_pause_intelligence", "System Intelligence Pausado", "Limita Android System Intelligence durante a partida", "Durante o jogo", "am set-standby-bucket com.google.android.as restricted", "am set-standby-bucket com.google.android.as active"),
        FeatureMeta("sys_whatsapp_no_dl", "WhatsApp Sem Download Automático", "Restringe tráfego em segundo plano do WhatsApp no jogo", "Durante o jogo", "cmd appops set com.whatsapp RUN_IN_BACKGROUND ignore", "cmd appops set com.whatsapp RUN_IN_BACKGROUND allow"),
        FeatureMeta("sys_pause_quickshare", "Quick Share Pausado no Jogo", "Suspende varredura BLE/Wi-Fi do Quick Share", "Durante o jogo", "", ""),

        // Sistema - Seção 2: Sempre ativo & Segundo plano
        FeatureMeta("sys_night_opt", "Otimização Noturna", "Executa manutenção AOT speed-profile ao carregar", "Segundo plano", "cmd package bg-dexopt-job", ""),
        FeatureMeta("sys_fast_storage", "Armazenamento Rápido", "Executa fstrim nos volumes de dados do usuário", "Segundo plano", "sm fstrim", ""),
        FeatureMeta("sys_clear_cache", "Limpar Cache Geral", "Libera caches temporários com trim-caches", "Segundo plano", "pm trim-caches 999G", ""),
        FeatureMeta("sys_lighter", "Sistema Mais Leve", "Aplica standby bucket econômico a apps ociosos", "Segundo plano", "", ""),
        FeatureMeta("sys_forbidden_bg", "Proibidos em Segundo Plano", "Aplica RUN_IN_BACKGROUND ignore aos apps escolhidos", "Segundo plano", "", ""),
        FeatureMeta("sys_no_oem_autostart", "Sem Início Automático da Marca", "Restringe inicialização automática de bloatwares OEM", "Segundo plano", "", ""),
        FeatureMeta("sys_no_preload", "Sem Pré-carregamento de Apps", "Desativa pré-carregamento preditivo em RAM", "Segundo plano", "settings put global app_standby_enabled 1", ""),

        // Sistema - Seção 3: Sistema silencioso & Android leve
        FeatureMeta("sys_no_crash_reports", "Sem Relatórios de Erro em Massa", "Limita geração repetitiva de relatórios dropbox/bugreport", "Sistema leve", "settings put global send_action_app_error 0", "settings put global send_action_app_error 1"),
        FeatureMeta("sys_clean_telemetry", "Limpeza de Telemetria", "Limpa buffers de telemetria de uso", "Sistema leve", "settings put global usage_stats_enabled 0", "settings put global usage_stats_enabled 1"),
        FeatureMeta("sys_clear_logs", "Limpar Pastas de Log", "Limpa buffer do logcat e logs temporários", "Sistema leve", "logcat -c", ""),
        FeatureMeta("sys_app_analyzer", "Analisador de Apps", "Audita consumo de wakelock e memória por pacote", "Sistema leve", "dumpsys procstats --hours 1", ""),
        FeatureMeta("sys_always_opt_apps", "Apps Sempre Otimizados", "Mantém compilação ART speed-profile atualizada", "Sistema leve", "cmd package compile -m speed-profile -a", ""),
        FeatureMeta("sys_post_update_turbo", "Pós-Atualização Turbo", "Recompila pacotes imediatamente após updates do sistema", "Sistema leve", "cmd package bg-dexopt-job", ""),
        FeatureMeta("sys_idle_sleep", "Apps Parados Dormindo", "Coloca apps sem uso recente em bucket working_set/frequent", "Sistema leve", "", ""),
        FeatureMeta("sys_forgotten_hibernate", "Apps Esquecidos Hibernando", "Hiberna pacotes inativos há mais de 14 dias", "Sistema leve", "", ""),
        FeatureMeta("sys_compile_system", "Apps do Sistema Compilados", "Compila APKs de sistema críticos com perfil speed", "Sistema leve", "cmd package compile -m speed-profile -f -a", ""),
        FeatureMeta("sys_fast_doze", "Doze Rápido", "Acelera entrada em modo Doze ao desligar a tela", "Sistema leve", "dumpsys deviceidle force-idle", "dumpsys deviceidle unforce"),
        FeatureMeta("sys_eco_location", "Localização de Fundo Econômica", "Reduz frequência de polling GPS em segundo plano", "Sistema leve", "settings put global location_background_throttle_interval_ms 60000", "settings delete global location_background_throttle_interval_ms"),
        FeatureMeta("sys_batch_jobs", "Tarefas de Fundo Agrupadas", "Agrupa JobScheduler para reduzir despertares de CPU", "Sistema leve", "", ""),
        FeatureMeta("sys_clean_giant_cache", "Caches Gigantes Limpos (>500 MB)", "Remove caches volumosos automaticamente", "Sistema leve", "pm trim-caches 512M", ""),

        // Sistema - Seção 4: Serviços Google & WebView
        FeatureMeta("gms_turbo", "Play Services Turbo", "Compila com.google.android.gms em modo speed-profile", "Google & WebView", "cmd package compile -m speed-profile -f com.google.android.gms", ""),
        FeatureMeta("gms_modules", "Módulos do Play Services", "Otimiza módulos dinâmicos do Google Play Services", "Google & WebView", "cmd package compile -m speed-profile com.google.android.gms", ""),
        FeatureMeta("gms_lean", "Play Services Enxuto", "Restringe telemetria secundária e libera cache do GMS", "Google & WebView", "", ""),
        FeatureMeta("gms_gboard", "Gboard Instantâneo", "Compila teclado Gboard para abertura imediata em jogos", "Google & WebView", "cmd package compile -m speed -f com.google.android.inputmethod.latin", ""),
        FeatureMeta("gms_playstore", "Play Store Rápida", "Otimiza cache e bytecode da Google Play Store", "Google & WebView", "cmd package compile -m speed-profile -f com.android.vending", ""),
        FeatureMeta("gms_google_app", "App Google Rápido", "Compila Google Search / Velvet com speed-profile", "Google & WebView", "cmd package compile -m speed-profile com.google.android.googlequicksearchbox", ""),
        FeatureMeta("gms_chrome", "Chrome Rápido", "Compila Google Chrome com profile AOT otimizado", "Google & WebView", "cmd package compile -m speed-profile com.android.chrome", ""),
        FeatureMeta("gms_youtube", "YouTube Rápido", "Compila YouTube com profile AOT para menor travamento", "Google & WebView", "cmd package compile -m speed-profile com.google.android.youtube", ""),
        FeatureMeta("gms_ai_compiled", "IA do Google Compilada", "Compila AICore / System Intelligence para baixa latência", "Google & WebView", "cmd package compile -m speed-profile com.google.android.aicore", ""),
        FeatureMeta("gms_always_opt", "Google Sempre Otimizado", "Revalida compilação dos pacotes Google após updates", "Google & WebView", "", ""),
        FeatureMeta("gms_play_games", "Play Games Compilado", "Compila Google Play Games em modo speed", "Google & WebView", "cmd package compile -m speed com.google.android.play.games", ""),
        FeatureMeta("wv_compiled", "WebView Compilado", "Compila Android System WebView em modo speed", "WebView", "cmd package compile -m speed -f com.google.android.webview", ""),
        FeatureMeta("wv_newest", "WebView Mais Novo", "Verifica e ativa o provedor WebView mais atualizado", "WebView", "cmd webviewupdate dump", ""),
        FeatureMeta("wv_single", "WebView Único", "Consolida provedor WebView ativo sem duplicidade", "WebView", "", ""),
        FeatureMeta("wv_always_compiled", "WebView Sempre Compilado", "Mantém WebView compilado após cada atualização", "WebView", "", "")
    )

    val masterScripts: List<MasterScriptItem> = listOf(
        MasterScriptItem(
            id = "script_aot_speed",
            title = "Compilação AOT Speed (Jogos)",
            description = "Compila pacotes de usuário com perfil speed-profile para abrir jogos mais rápido e reduzir engasgos de JIT.",
            category = "Compilação AOT",
            command = "cmd package compile -m speed-profile -a",
            undoCommand = "cmd package compile --reset -a",
            timeoutSeconds = 30
        ),
        MasterScriptItem(
            id = "script_fixed_perf",
            title = "Travar Modo Performance Fixa",
            description = "Ativa fixed-performance-mode no PowerManager para evitar quedas abruptas de clock durante partidas.",
            category = "CPU / Clock",
            command = "cmd power set-fixed-performance-mode-enabled true",
            undoCommand = "cmd power set-fixed-performance-mode-enabled false",
            timeoutSeconds = 8
        ),
        MasterScriptItem(
            id = "script_anim_half",
            title = "Escala de Animação 0.5x",
            description = "Deixa janelas, transições e animações duas vezes mais rápidas na interface Android.",
            category = "Interface & GPU",
            command = "settings put global window_animation_scale 0.5 && settings put global transition_animation_scale 0.5 && settings put global animator_duration_scale 0.5",
            undoCommand = "settings put global window_animation_scale 1.0 && settings put global transition_animation_scale 1.0 && settings put global animator_duration_scale 1.0",
            timeoutSeconds = 8
        ),
        MasterScriptItem(
            id = "script_trim_caches",
            title = "Limpeza Profunda de Cache & FSTRIM",
            description = "Executa trim de caches ociosos e fstrim no armazenamento flash para recuperar leitura/escrita rápida.",
            category = "Armazenamento",
            command = "pm trim-caches 999G && sm fstrim",
            undoCommand = "",
            timeoutSeconds = 20
        ),
        MasterScriptItem(
            id = "script_doze_idle",
            title = "Forçar Doze em Apps Ociosos",
            description = "Reduz consumo de bateria e processos paralelos antes de iniciar uma sessão competitiva.",
            category = "Segundo Plano",
            command = "dumpsys deviceidle force-idle",
            undoCommand = "dumpsys deviceidle unforce",
            timeoutSeconds = 8
        ),
        MasterScriptItem(
            id = "script_webview_aot",
            title = "Compilar WebView + Play Services",
            description = "Compila WebView e Google Play Services para reduzir travamentos em menus web e login in-game.",
            category = "Google & WebView",
            command = "cmd package compile -m speed -f com.google.android.webview && cmd package compile -m speed-profile com.google.android.gms",
            undoCommand = "cmd package compile --reset com.google.android.webview",
            timeoutSeconds = 25
        ),
        MasterScriptItem(
            id = "script_disable_blur",
            title = "Desativar Desfoque de Janela (Zero Blur)",
            description = "Remove custo extra de shader de blur em janelas e notificações sobrepostas ao jogo.",
            category = "Renderização",
            command = "settings put global disable_window_blurs 1",
            undoCommand = "settings put global disable_window_blurs 0",
            timeoutSeconds = 8
        ),
        MasterScriptItem(
            id = "script_reset_display",
            title = "Resgate de Tela (Reset Size & Density)",
            description = "Restaura imediatamente resolução e DPI padrão de fábrica caso um ajuste de tela fique desproporcional.",
            category = "Resgate",
            command = "wm size reset && wm density reset",
            undoCommand = "",
            timeoutSeconds = 8
        )
    )
}
