package com.raylan.mastervoid.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.raylan.mastervoid.security.SecurityCheckResult

@Composable
fun SecurityBlockScreen(
    securityStatus: SecurityCheckResult,
    onUninstallClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF2B0508))
            .safeDrawingPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF450A0A), RoundedCornerShape(20.dp))
                .border(2.dp, Color(0xFFEF4444), RoundedCornerShape(20.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = "Alerta Crítico de Segurança",
                tint = Color(0xFFFCA5A5),
                modifier = Modifier.size(64.dp)
            )
            Text(
                text = "ALERTA DE SEGURANÇA: Aplicativo Master Void modificado detectado!",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "O sistema de proteção bloqueou a execução para preservar a integridade do aparelho e do projeto original.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFFECACA),
                textAlign = TextAlign.Center
            )
            if (securityStatus.violations.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF2B0508), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    securityStatus.violations.forEach { violation ->
                        Text(
                            text = "• $violation",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFFCA5A5)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = onUninstallClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("security_uninstall_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDC2626),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("DESINSTALAR APLICATIVO AGORA", fontWeight = FontWeight.Bold)
            }
        }
    }
}
