package com.raylan.mastervoid.ui.theme

import androidx.compose.ui.graphics.Color

val VoidBackground = Color(0xFF0B0B10)
val VoidSurface = Color(0xFF101018)
val VoidCard = Color(0xFF14141E)
val VoidCardElevated = Color(0xFF1A1A28)
val VoidBorder = Color(0xFF26263A)

val VoidPurple = Color(0xFF8B5CF6)
val VoidCyan = Color(0xFF00E5FF)

val VoidTextPrimary = Color(0xFFF4F4F8)
val VoidTextSecondary = Color(0xFF9CA3AF)
val VoidTextMuted = Color(0xFF6B7280)

val VoidGreen = Color(0xFF10B981)
val VoidAmber = Color(0xFFF59E0B)
val VoidRed = Color(0xFFEF4444)

data class VoidThemePalette(
    val name: String,
    val primary: Color,
    val secondary: Color
)

val MasterVoidThemes = listOf(
    VoidThemePalette("Roxo Void", Color(0xFF8B5CF6), Color(0xFF00E5FF)),
    VoidThemePalette("Ciano Elétrico", Color(0xFF00E5FF), Color(0xFF8B5CF6)),
    VoidThemePalette("Azul Gojo", Color(0xFF3B82F6), Color(0xFF38BDF8)),
    VoidThemePalette("Verde Matrix", Color(0xFF10B981), Color(0xFF34D399)),
    VoidThemePalette("Carmesim Cyber", Color(0xFFEF4444), Color(0xFFFB7185)),
    VoidThemePalette("Solar Plasma", Color(0xFFF59E0B), Color(0xFFFACC15)),
    VoidThemePalette("Rosa Neon", Color(0xFFEC4899), Color(0xFFA855F7)),
    VoidThemePalette("Índigo Astral", Color(0xFF6366F1), Color(0xFF22D3EE)),
    VoidThemePalette("Lima Turbo", Color(0xFF84CC16), Color(0xFF2DD4BF)),
    VoidThemePalette("Prata Titânio", Color(0xFFE2E8F0), Color(0xFF38BDF8))
)
