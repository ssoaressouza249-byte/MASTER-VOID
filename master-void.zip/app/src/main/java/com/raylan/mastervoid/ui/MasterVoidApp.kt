package com.raylan.mastervoid.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.mastervoid.model.GameSubTab
import com.raylan.mastervoid.model.MainTab
import com.raylan.mastervoid.ui.screens.GameScreen
import com.raylan.mastervoid.ui.screens.HomeScreen
import com.raylan.mastervoid.ui.screens.ModulesScreen
import com.raylan.mastervoid.ui.screens.SystemScreen
import com.raylan.mastervoid.ui.theme.VoidBackground
import com.raylan.mastervoid.ui.theme.VoidBorder
import com.raylan.mastervoid.ui.theme.VoidCard
import com.raylan.mastervoid.ui.theme.VoidGreen
import com.raylan.mastervoid.ui.theme.VoidSurface
import com.raylan.mastervoid.ui.theme.VoidTextMuted
import com.raylan.mastervoid.ui.theme.VoidTextPrimary
import com.raylan.mastervoid.ui.theme.VoidTextSecondary
import com.raylan.mastervoid.viewmodel.MasterVoidViewModel

@Composable
fun MasterVoidApp(viewModel: MasterVoidViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val bannerMessage by viewModel.statusBannerMessage.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(MainTab.HOME) }
    var currentGameSubTab by remember { mutableStateOf(GameSubTab.GAMES_ENGINE) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(bannerMessage) {
        bannerMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    BackHandler(enabled = currentTab != MainTab.HOME || currentGameSubTab != GameSubTab.GAMES_ENGINE) {
        if (currentTab == MainTab.GAME && currentGameSubTab != GameSubTab.GAMES_ENGINE) {
            currentGameSubTab = GameSubTab.GAMES_ENGINE
        } else {
            currentTab = MainTab.HOME
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBackground),
        containerColor = VoidBackground,
        contentWindowInsets = WindowInsets.statusBars,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VoidSurface)
            ) {
                FixedMasterControlCard(
                    enabled = state.masterEnabled,
                    activeCount = viewModel.activeFeatureCount(),
                    onToggle = { viewModel.toggleMasterEnabled() }
                )
                NavigationBar(
                    containerColor = VoidSurface,
                    windowInsets = WindowInsets.navigationBars,
                    tonalElevation = 0.dp
                ) {
                    MainTab.entries.forEach { tab ->
                        val selected = currentTab == tab
                        val icon = when (tab) {
                            MainTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
                            MainTab.GAME -> if (selected) Icons.Filled.SportsEsports else Icons.Outlined.SportsEsports
                            MainTab.SYSTEM -> if (selected) Icons.Filled.Tune else Icons.Outlined.Tune
                            MainTab.MODULES -> if (selected) Icons.Filled.Extension else Icons.Outlined.Extension
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentTab = tab },
                            modifier = Modifier.testTag("nav_${tab.name.lowercase()}"),
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tab.label
                                )
                            },
                            label = {
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.secondary,
                                selectedTextColor = MaterialTheme.colorScheme.secondary,
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                unselectedIconColor = VoidTextMuted,
                                unselectedTextColor = VoidTextMuted
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MainTab.HOME -> HomeScreen(
                    state = state,
                    telemetry = telemetry,
                    shizukuStatus = shizukuStatus,
                    onToggleBannerAnimation = viewModel::toggleAnimateBanner,
                    onRequestShizuku = viewModel.shizukuEngine::requestPermissionOrOpenShizuku,
                    onSelectProfile = viewModel::selectProfile,
                    onToggleFeature = viewModel::toggleFeature,
                    onToggleFavorite = viewModel::toggleFavorite
                )

                MainTab.GAME -> GameScreen(
                    state = state,
                    installedApps = installedApps,
                    selectedSubTab = currentGameSubTab,
                    onSelectSubTab = { currentGameSubTab = it },
                    viewModel = viewModel
                )

                MainTab.SYSTEM -> SystemScreen(
                    state = state,
                    telemetry = telemetry,
                    installedApps = installedApps,
                    viewModel = viewModel
                )

                MainTab.MODULES -> ModulesScreen(
                    state = state,
                    shizukuStatus = shizukuStatus,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
private fun FixedMasterControlCard(
    enabled: Boolean,
    activeCount: Int,
    onToggle: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onToggle)
            .testTag("fixed_master_card"),
        color = VoidCard,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (enabled) primary.copy(alpha = 0.75f) else VoidBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (enabled) primary.copy(alpha = 0.2f) else VoidBorder.copy(alpha = 0.4f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PowerSettingsNew,
                        contentDescription = "Ativar ou Desativar Master Void",
                        tint = if (enabled) secondary else VoidTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Ativar / Desativar Master Void",
                        style = MaterialTheme.typography.titleSmall,
                        color = VoidTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (enabled) "Ativo • $activeCount funções trabalhando" else "Desativado • Tudo revertido",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (enabled) VoidGreen else VoidTextSecondary
                    )
                }
            }
            Switch(
                checked = enabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = primary,
                    uncheckedThumbColor = VoidTextSecondary,
                    uncheckedTrackColor = VoidBackground,
                    uncheckedBorderColor = VoidBorder
                )
            )
        }
    }
}
