package com.raylan.mastervoid.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.mastervoid.model.MasterScriptItem
import com.raylan.mastervoid.model.MasterVoidCatalog
import com.raylan.mastervoid.model.MasterVoidState
import com.raylan.mastervoid.shizuku.ShizukuStatus
import com.raylan.mastervoid.ui.components.MasterVoidFooter
import com.raylan.mastervoid.ui.components.VoidCardContainer
import com.raylan.mastervoid.ui.components.VoidSearchBar
import com.raylan.mastervoid.ui.components.VoidSectionHeader
import com.raylan.mastervoid.ui.theme.VoidBorder
import com.raylan.mastervoid.ui.theme.VoidCard
import com.raylan.mastervoid.ui.theme.VoidCardElevated
import com.raylan.mastervoid.ui.theme.VoidGreen
import com.raylan.mastervoid.ui.theme.VoidTextMuted
import com.raylan.mastervoid.ui.theme.VoidTextPrimary
import com.raylan.mastervoid.ui.theme.VoidTextSecondary
import com.raylan.mastervoid.viewmodel.MasterVoidViewModel

@Composable
fun ModulesScreen(
    state: MasterVoidState,
    shizukuStatus: ShizukuStatus,
    viewModel: MasterVoidViewModel
) {
    var query by remember { mutableStateOf("") }
    var previewScript by remember { mutableStateOf<MasterScriptItem?>(null) }
    var consoleOutput by remember { mutableStateOf(state.lastCommandOutput) }

    val filteredScripts = remember(query) {
        if (query.isBlank()) MasterVoidCatalog.masterScripts
        else MasterVoidCatalog.masterScripts.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true) ||
                it.command.contains(query, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(6.dp))
            VoidSectionHeader(
                title = "Scripts Master",
                subtitle = "Executor shell/ADB via Shizuku com prévia, limite de tempo e Desfazer",
                badge = shizukuStatus.label
            )
        }

        item {
            VoidSearchBar(
                query = query,
                onQueryChange = { query = it },
                placeholder = "Buscar módulos e scripts ADB..."
            )
        }

        if (consoleOutput.isNotBlank()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF09090F),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Saída do Terminal Master Void",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = consoleOutput,
                            style = MaterialTheme.typography.labelMedium,
                            color = VoidGreen
                        )
                    }
                }
            }
        }

        items(filteredScripts, key = { it.id }) { script ->
            VoidCardContainer {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = script.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = VoidTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = script.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(VoidCardElevated)
                            .border(1.dp, VoidBorder, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Timer,
                            contentDescription = "Timeout",
                            tint = VoidTextMuted,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "${script.timeoutSeconds}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = VoidTextSecondary
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = script.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = VoidTextSecondary
                )
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0A0A0F))
                        .border(1.dp, VoidBorder, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "$ ${script.command}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { previewScript = script },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("preview_${script.id}"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Prévia e rodar", modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Prévia e Rodar")
                    }
                    if (script.undoCommand.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                viewModel.undoMasterScript(script) { out -> consoleOutput = out }
                            },
                            modifier = Modifier.testTag("undo_${script.id}"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.Undo, contentDescription = "Desfazer", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Desfazer")
                        }
                    }
                }
            }
        }

        item {
            MasterVoidFooter()
        }
    }

    previewScript?.let { script ->
        AlertDialog(
            onDismissRequest = { previewScript = null },
            containerColor = VoidCard,
            icon = {
                Icon(
                    imageVector = Icons.Filled.Terminal,
                    contentDescription = "Prévia do script",
                    tint = MaterialTheme.colorScheme.secondary
                )
            },
            title = {
                Text("Prévia antes de executar", color = VoidTextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(script.title, style = MaterialTheme.typography.titleSmall, color = VoidTextPrimary)
                    Text(
                        text = "Limite de tempo: ${script.timeoutSeconds} segundos",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF09090F), RoundedCornerShape(10.dp))
                            .border(1.dp, VoidBorder, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = script.command,
                            style = MaterialTheme.typography.labelSmall,
                            color = VoidGreen
                        )
                    }
                    if (script.undoCommand.isNotBlank()) {
                        Text(
                            text = "Reversão disponível: ${script.undoCommand}",
                            style = MaterialTheme.typography.labelSmall,
                            color = VoidTextMuted
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val target = script
                    previewScript = null
                    viewModel.runMasterScript(target) { out -> consoleOutput = out }
                }) {
                    Text("Executar agora")
                }
            },
            dismissButton = {
                TextButton(onClick = { previewScript = null }) {
                    Text("Cancelar", color = VoidTextSecondary)
                }
            }
        )
    }
}
