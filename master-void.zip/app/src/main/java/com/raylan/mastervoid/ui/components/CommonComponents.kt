package com.raylan.mastervoid.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.mastervoid.telemetry.InstalledAppItem
import com.raylan.mastervoid.ui.theme.VoidBorder
import com.raylan.mastervoid.ui.theme.VoidCard
import com.raylan.mastervoid.ui.theme.VoidCardElevated
import com.raylan.mastervoid.ui.theme.VoidTextMuted
import com.raylan.mastervoid.ui.theme.VoidTextPrimary
import com.raylan.mastervoid.ui.theme.VoidTextSecondary

@Composable
fun VoidCardContainer(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    accentBorder: Color = MaterialTheme.colorScheme.primary,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = VoidCard,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (highlighted) accentBorder.copy(alpha = 0.65f) else VoidBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            content = content
        )
    }
}

@Composable
fun VoidSectionHeader(
    title: String,
    subtitle: String? = null,
    badge: String? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = VoidTextPrimary,
                fontWeight = FontWeight.Bold
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = VoidTextSecondary
                )
            }
        }
        if (!badge.isNullOrBlank()) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badge,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@Composable
fun VoidFeatureToggleRow(
    featureId: String,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    isFavorite: Boolean? = null,
    onFavoriteToggle: (() -> Unit)? = null,
    hapticEnabled: Boolean = true
) {
    val haptic = LocalHapticFeedback.current
    val primary = MaterialTheme.colorScheme.primary
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("toggle_$featureId"),
        color = if (checked) primary.copy(alpha = 0.09f) else VoidCardElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (checked) primary.copy(alpha = 0.5f) else VoidBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (hapticEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onCheckedChange(!checked)
                }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isFavorite != null && onFavoriteToggle != null) {
                IconButton(
                    onClick = {
                        if (hapticEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onFavoriteToggle()
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("fav_$featureId")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favoritar $title",
                        tint = if (isFavorite) Color(0xFFFACC15) else VoidTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = VoidTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = VoidTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Switch(
                checked = checked,
                onCheckedChange = {
                    if (hapticEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onCheckedChange(it)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = primary,
                    uncheckedThumbColor = VoidTextSecondary,
                    uncheckedTrackColor = VoidCard,
                    uncheckedBorderColor = VoidBorder
                )
            )
        }
    }
}

@Composable
fun VoidOptionChipRow(
    label: String,
    options: List<String>,
    selectedOption: String,
    onSelect: (String) -> Unit,
    hapticEnabled: Boolean = true
) {
    val haptic = LocalHapticFeedback.current
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            color = VoidTextPrimary,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { option ->
                val selected = option == selectedOption
                FilterChip(
                    selected = selected,
                    onClick = {
                        if (hapticEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(option)
                    },
                    label = {
                        Text(
                            text = option,
                            style = MaterialTheme.typography.labelMedium
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.24f),
                        selectedLabelColor = MaterialTheme.colorScheme.secondary,
                        containerColor = VoidCardElevated,
                        labelColor = VoidTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selected,
                        borderColor = VoidBorder,
                        selectedBorderColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }
    }
}

@Composable
fun VoidSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholder: String = "Buscar: lag, calor, mira...",
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier
            .fillMaxWidth()
            .testTag("search_bar"),
        placeholder = {
            Text(
                text = placeholder,
                style = MaterialTheme.typography.bodyMedium,
                color = VoidTextMuted
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Buscar",
                tint = MaterialTheme.colorScheme.secondary
            )
        },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Limpar busca",
                        tint = VoidTextSecondary
                    )
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = VoidBorder,
            focusedContainerColor = VoidCard,
            unfocusedContainerColor = VoidCard,
            focusedTextColor = VoidTextPrimary,
            unfocusedTextColor = VoidTextPrimary
        )
    )
}

@Composable
fun MasterVoidFooter() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Master Void 1.0 • Desenvolvido por Raylan",
            style = MaterialTheme.typography.labelSmall,
            color = VoidTextMuted
        )
    }
}

@Composable
fun AppIconImage(
    drawable: Drawable?,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    val bitmap = remember(drawable) {
        drawable?.let {
            val w = it.intrinsicWidth.coerceIn(48, 128)
            val h = it.intrinsicHeight.coerceIn(48, 128)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            it.setBounds(0, 0, w, h)
            it.draw(canvas)
            bmp.asImageBitmap()
        }
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = contentDescription,
            modifier = modifier.clip(RoundedCornerShape(10.dp))
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = contentDescription.take(1).uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun AppPickerDialog(
    title: String,
    apps: List<InstalledAppItem>,
    loadIcon: (String) -> Drawable?,
    onSelect: (InstalledAppItem) -> Unit,
    onDismiss: () -> Unit
) {
    var filter by remember { mutableStateOf("") }
    val filtered = remember(apps, filter) {
        if (filter.isBlank()) apps
        else apps.filter {
            it.label.contains(filter, ignoreCase = true) ||
                it.packageName.contains(filter, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VoidCard,
        title = {
            Text(title, style = MaterialTheme.typography.titleMedium, color = VoidTextPrimary)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                VoidSearchBar(
                    query = filter,
                    onQueryChange = { filter = it },
                    placeholder = "Filtrar aplicativos instalados..."
                )
                if (filtered.isEmpty()) {
                    Text(
                        text = "Nenhum aplicativo encontrado.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VoidTextSecondary
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 340.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filtered, key = { it.packageName }) { app ->
                            val icon = remember(app.packageName) { loadIcon(app.packageName) }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(VoidCardElevated)
                                    .border(1.dp, VoidBorder, RoundedCornerShape(12.dp))
                                    .clickable { onSelect(app) }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIconImage(
                                    drawable = icon,
                                    contentDescription = app.label,
                                    modifier = Modifier.size(38.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = VoidTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VoidTextMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (app.isGame) {
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "JOGO",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar", color = MaterialTheme.colorScheme.secondary)
            }
        }
    )
}

@Composable
fun TouchTester120HzDialog(
    onDismiss: () -> Unit
) {
    val trailPoints = remember { mutableStateListOf<Offset>() }
    var lastEventNs by remember { mutableLongStateOf(0L) }
    var measuredHz by remember { mutableStateOf(0) }
    var avgLatencyMs by remember { mutableStateOf(0f) }

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VoidCard,
        title = {
            Text("Testador de Toque 120Hz", style = MaterialTheme.typography.titleMedium, color = VoidTextPrimary)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Taxa: ${measuredHz} Hz",
                        style = MaterialTheme.typography.labelMedium,
                        color = secondary
                    )
                    Text(
                        text = "Intervalo: ${"%.1f".format(avgLatencyMs)} ms",
                        style = MaterialTheme.typography.labelMedium,
                        color = primary
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF07070B))
                        .border(1.dp, secondary.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val now = System.nanoTime()
                                    if (lastEventNs > 0L) {
                                        val dtNs = (now - lastEventNs).coerceAtLeast(1_000_000L)
                                        val hz = (1_000_000_000.0 / dtNs).toInt().coerceIn(1, 480)
                                        measuredHz = hz
                                        avgLatencyMs = dtNs / 1_000_000f
                                    }
                                    lastEventNs = now
                                    event.changes.forEach { change ->
                                        trailPoints.add(change.position)
                                        if (trailPoints.size > 48) {
                                            trailPoints.removeAt(0)
                                        }
                                    }
                                }
                            }
                        }
                ) {
                    ComposeCanvas(modifier = Modifier.fillMaxSize()) {
                        for (i in 1 until trailPoints.size) {
                            val alpha = i.toFloat() / trailPoints.size.coerceAtLeast(1)
                            drawLine(
                                color = secondary.copy(alpha = alpha),
                                start = trailPoints[i - 1],
                                end = trailPoints[i],
                                strokeWidth = 6f
                            )
                        }
                        trailPoints.lastOrNull()?.let { pt ->
                            drawCircle(
                                color = primary,
                                radius = 18f,
                                center = pt,
                                style = Stroke(width = 3f)
                            )
                        }
                    }
                    if (trailPoints.isEmpty()) {
                        Text(
                            text = "Deslize o dedo aqui rapidamente",
                            style = MaterialTheme.typography.bodySmall,
                            color = VoidTextMuted,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                trailPoints.clear()
                measuredHz = 0
                avgLatencyMs = 0f
            }) {
                Text("Limpar", color = VoidTextSecondary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar", color = secondary)
            }
        }
    )
}
