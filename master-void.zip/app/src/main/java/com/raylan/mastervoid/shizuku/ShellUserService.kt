package com.raylan.mastervoid.shizuku

import com.raylan.mastervoid.IShellService
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

class ShellUserService : IShellService.Stub() {

    override fun exec(command: String?, timeoutSeconds: Int): String {
        if (command.isNullOrBlank()) return ""
        val safeTimeout = timeoutSeconds.coerceIn(1, 60)
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val readerThread = Thread {
                reader.useLines { lines ->
                    lines.forEach { line ->
                        if (output.length < 16_000) {
                            output.appendLine(line)
                        }
                    }
                }
            }
            readerThread.start()
            val finished = process.waitFor(safeTimeout.toLong(), TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                readerThread.join(300)
                return "${output}\n[TIMEOUT após ${safeTimeout}s]"
            }
            readerThread.join(500)
            val exitCode = process.exitValue()
            val result = output.toString().trim()
            if (exitCode == 0) {
                result.ifEmpty { "OK" }
            } else {
                "[EXIT $exitCode] $result".trim()
            }
        } catch (t: Throwable) {
            "[ERRO] ${t.message ?: t.javaClass.simpleName}"
        }
    }

    override fun destroy() {
        exitProcess(0)
    }
}
