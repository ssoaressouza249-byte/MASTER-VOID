package com.raylan.mastervoid.security

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import com.raylan.mastervoid.R
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

data class SecurityCheckResult(
    val isIntact: Boolean,
    val violations: List<String> = emptyList(),
    val certificateSha256: String = "",
    val certificateSubject: String = ""
)

object SecurityGuard {

    private const val EXPECTED_PACKAGE = "com.raylan.mastervoid"
    private const val EXPECTED_APP_NAME = "Master Void"

    private val MOD_TOOL_PACKAGES = listOf(
        "bin.mt.plus" to "MT Manager",
        "bin.mt.plus.canary" to "MT Manager Canary",
        "np.manager" to "NP Manager",
        "com.gmail.heagoo.apkeditor" to "APK Editor"
    )

    fun verifyIntegrity(context: Context): SecurityCheckResult {
        val violations = mutableListOf<String>()
        val pm = context.packageManager

        // 1. Package name check
        if (context.packageName != EXPECTED_PACKAGE) {
            violations += "Pacote adulterado detectado: ${context.packageName}"
        }

        // 2. App name check (resources & applicationInfo label)
        val resAppName = runCatching { context.getString(R.string.app_name) }.getOrNull()
        val manifestLabel = runCatching {
            val appInfo = pm.getApplicationInfo(context.packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        }.getOrNull()

        if (resAppName != EXPECTED_APP_NAME || (manifestLabel != null && manifestLabel != EXPECTED_APP_NAME)) {
            violations += "Identidade do aplicativo alterada ($resAppName / $manifestLabel)"
        }

        // 3. Manifest component integrity check
        val manifestPackageInfo = getPackageInfoCompat(
            pm,
            context.packageName,
            PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or PackageManager.GET_PROVIDERS
        )
        if (manifestPackageInfo == null) {
            violations += "Falha ao inspecionar manifesto do aplicativo"
        } else {
            val hasMainActivity = manifestPackageInfo.activities?.any {
                it.name == "$EXPECTED_PACKAGE.MainActivity"
            } == true
            val hasHudService = manifestPackageInfo.services?.any {
                it.name == "$EXPECTED_PACKAGE.service.FloatingHudService"
            } == true
            val hasShizukuProvider = manifestPackageInfo.providers?.any {
                it.name == "rikka.shizuku.ShizukuProvider"
            } == true

            if (!hasMainActivity || !hasHudService || !hasShizukuProvider) {
                violations += "Manifesto modificado: componentes essenciais ausentes"
            }
        }

        // 4. X.509 Signature verification
        var certSha256 = ""
        var certSubject = ""
        val sigPackageInfo = getPackageInfoCompat(
            pm,
            context.packageName,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageManager.GET_SIGNING_CERTIFICATES
            } else {
                @Suppress("DEPRECATION")
                PackageManager.GET_SIGNATURES
            }
        )

        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = sigPackageInfo?.signingInfo
            if (signingInfo?.hasMultipleSigners() == true) {
                signingInfo.apkContentsSigners
            } else {
                signingInfo?.signingCertificateHistory
            }
        } else {
            @Suppress("DEPRECATION")
            sigPackageInfo?.signatures
        }

        if (signatures.isNullOrEmpty()) {
            violations += "Assinatura X.509 ausente ou corrompida"
        } else {
            runCatching {
                val certFactory = CertificateFactory.getInstance("X.509")
                val x509 = certFactory.generateCertificate(
                    ByteArrayInputStream(signatures.first().toByteArray())
                ) as X509Certificate
                x509.checkValidity()
                val digest = MessageDigest.getInstance("SHA-256").digest(x509.encoded)
                certSha256 = digest.joinToString(":") { "%02X".format(it) }
                certSubject = x509.subjectX500Principal.name
                if (certSha256.isBlank()) {
                    violations += "Impressão digital SHA-256 inválida"
                }
            }.onFailure {
                violations += "Certificado X.509 inválido ou expirado: ${it.message}"
            }
        }

        // 5. Modification tools installed check
        MOD_TOOL_PACKAGES.forEach { (pkg, label) ->
            if (isPackageInstalled(pm, pkg)) {
                violations += "Ferramenta de modificação detectada: $label ($pkg)"
            }
        }

        return SecurityCheckResult(
            isIntact = violations.isEmpty(),
            violations = violations,
            certificateSha256 = certSha256,
            certificateSubject = certSubject
        )
    }

    fun triggerUninstallIntent(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return getPackageInfoCompat(pm, packageName, 0) != null
    }

    private fun getPackageInfoCompat(
        pm: PackageManager,
        packageName: String,
        flags: Int
    ): PackageInfo? {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, flags)
            }
        }.getOrNull()
    }
}
