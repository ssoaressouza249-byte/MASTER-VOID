package com.raylan.mastervoid;

interface IShellService {
    String exec(String command, int timeoutSeconds);
    void destroy();
}
